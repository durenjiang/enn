# -*- coding: utf-8 -*-
"""
Conversation Manager for Agent multi-turn chat.

Manages conversation sessions with TTL, storing message history and context.
"""

import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.storage import ChatSessionStateConflict, get_db

logger = logging.getLogger(__name__)

@dataclass
class ConversationSession:
    """A single multi-turn conversation session."""
    session_id: str
    context: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    last_active: datetime = field(default_factory=datetime.now)

    def add_message(self, role: str, content: str, *, accepted_turn=None, db_manager=None) -> Optional[int]:
        """Add a message to the session history."""
        db = db_manager if db_manager is not None else get_db()
        message_id = db.save_conversation_message(self.session_id, role, content, accepted_turn=accepted_turn)
        self.last_active = datetime.now()
        return message_id

    def add_user_message(
        self,
        content: str,
        selected_skill_ids: Optional[List[str]] = None,
    ) -> int:
        """Add a user message and optionally update the persisted Skill selection."""
        message_id = get_db().save_conversation_user_turn(
            self.session_id,
            content,
            selected_skill_ids,
        )
        self.last_active = datetime.now()
        return message_id

    def update_context(self, key: str, value: Any):
        """Update session context."""
        self.context[key] = value
        self.last_active = datetime.now()

    def get_history(self) -> List[Dict[str, Any]]:
        """Get message history."""
        messages = get_db().get_conversation_history(self.session_id)
        return messages

class ConversationManager:
    """Manages multiple conversation sessions with TTL."""
    
    def __init__(self, ttl_minutes: int = 30):
        self._sessions: Dict[str, ConversationSession] = {}
        self.ttl = timedelta(minutes=ttl_minutes)
        self._lock = threading.RLock()

    def get_or_create(self, session_id: str) -> ConversationSession:
        """Get an existing session or create a new one."""
        with self._lock:
            self._cleanup_expired()

            if session_id not in self._sessions:
                self._sessions[session_id] = ConversationSession(session_id=session_id)
                logger.info(f"Created new conversation session: {session_id}")
            else:
                # Update last active time
                self._sessions[session_id].last_active = datetime.now()

            return self._sessions[session_id]

    def add_message(self, session_id: str, role: str, content: str, *, accepted_turn=None, db_manager=None) -> Optional[int]:
        """Add a message to a session."""
        session = self.get_or_create(session_id)
        return session.add_message(role, content, accepted_turn=accepted_turn, db_manager=db_manager)

    def prepare_turn(self, session_id: str):
        """Bind the database instance before history preparation/model work."""
        self.get_or_create(session_id)
        db = get_db()
        generation = db.ensure_chat_session_generation(session_id)
        snapshot = db.read_chat_session_snapshot(session_id)
        if snapshot["session_generation"] != generation:
            raise ChatSessionStateConflict()
        return db, snapshot

    def commit_user_turn(
        self, db, snapshot, content: str, selected_skill_ids=None, *, state_disposition="legacy-unaware",
    ):
        """Save once under the prepared instance; return its actual source anchor."""
        accepted = db.commit_legacy_chat_user_turn(
            snapshot, content, selected_skill_ids, state_disposition=state_disposition,
        )
        self.get_or_create(snapshot["session_id"]).last_active = datetime.now()
        return accepted

    def add_user_message(
        self,
        session_id: str,
        content: str,
        selected_skill_ids: Optional[List[str]] = None,
    ) -> int:
        """Add a user message through the session-state transaction boundary."""
        session = self.get_or_create(session_id)
        return session.add_user_message(content, selected_skill_ids)

    def get_history(self, session_id: str) -> List[Dict[str, Any]]:
        """Get message history for a session."""
        session = self.get_or_create(session_id)
        return session.get_history()

    def clear(self, session_id: str):
        """Clear a session."""
        with self._lock:
            if session_id in self._sessions:
                del self._sessions[session_id]
                logger.info(f"Cleared conversation session: {session_id}")
        # We don't delete from DB here to keep history, or we could add a delete method.
        # For now, just clear from memory.

    def _cleanup_expired(self):
        """Remove expired sessions."""
        with self._lock:
            now = datetime.now()
            expired = [
                sid for sid, session in self._sessions.items()
                if now - session.last_active > self.ttl
            ]
            for sid in expired:
                del self._sessions[sid]
                logger.info(f"Cleaned up expired conversation session: {sid}")

# Global instance
conversation_manager = ConversationManager()
