#!/usr/bin/env python3
"""用真实临时 Git 仓库回归验证：索引不能先于报告原文发布。"""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]


class ReportsIndexTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.repo = Path(self.temp.name)
        (self.repo / "tools").mkdir()
        (self.repo / "reports/_index").mkdir(parents=True)
        shutil.copy(ROOT / "tools/reports_index.py", self.repo / "tools/reports_index.py")
        shutil.copy(ROOT / "reports/_index/config.json", self.repo / "reports/_index/config.json")
        self.write("README.md", "# 测试索引\n")
        self.write("reports/茅台/中文 历史报告.md", "# 历史报告\n")
        self.git("init", "-q")
        self.git("config", "core.quotePath", "true")
        self.git("add", ".")
        self.git("-c", "user.name=Index Test", "-c", "user.email=index@example.invalid",
                 "commit", "-qm", "baseline")

    def git(self, *args):
        env = dict(os.environ, GIT_AUTHOR_DATE="2026-09-30T12:00:00+08:00",
                   GIT_COMMITTER_DATE="2026-09-30T12:00:00+08:00")
        return subprocess.run(["git", *args], cwd=self.repo, env=env,
                              capture_output=True, text=True, check=True)

    def write(self, name, content):
        path = self.repo / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def run_index(self, *args, expected=0):
        result = subprocess.run([sys.executable, "tools/reports_index.py", *args],
                                cwd=self.repo, capture_output=True, text=True)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return result

    def items(self):
        return json.loads((self.repo / "reports/index.json").read_text(encoding="utf-8"))["reports"]

    def test_local_drafts_ignored_files_and_intent_to_add_are_not_published(self):
        self.write(".gitignore", "reports/私有/\n")
        for path in ("reports/七公司投资研究-20261002/茅台/报告-20261002.md",
                     "reports/私有/报告.md", "reports/仅占位/报告.md"):
            self.write(path, "# 本地未发布标题\n")
        self.git("add", "-N", "reports/仅占位/报告.md")
        output = self.run_index().stdout
        self.assertEqual([i["path"] for i in self.items()], ["reports/茅台/中文 历史报告.md"])
        self.assertNotIn("本地未发布标题", (self.repo / "reports/README.md").read_text(encoding="utf-8"))
        self.assertNotIn("七公司投资研究", output)
        self.run_index("--check")

    def test_staged_report_is_included_and_unstaging_invalidates_index(self):
        path = "reports/七公司投资研究-20261002/茅台/报告-20261002.md"
        self.write(path, "# 新报告\n")
        self.git("add", "--", path)
        self.run_index()
        self.assertIn(path, [i["path"] for i in self.items()])
        self.run_index("--check")
        self.git("reset", "-q", "HEAD", "--", path)
        before = (self.repo / "reports/index.json").read_bytes()
        self.run_index("--check", expected=1)
        self.assertEqual(before, (self.repo / "reports/index.json").read_bytes())
        self.run_index()
        self.assertNotIn(path, [i["path"] for i in self.items()])

    def test_removing_report_from_git_excludes_remaining_working_copy(self):
        self.run_index()
        path = "reports/茅台/中文 历史报告.md"
        self.git("rm", "--cached", "--", path)
        self.assertTrue((self.repo / path).is_file())
        self.run_index("--check", expected=1)
        self.run_index()
        self.assertEqual(self.items(), [])

    def test_git_failure_does_not_overwrite_published_index(self):
        self.run_index()
        before = (self.repo / "reports/index.json").read_bytes()
        shutil.rmtree(self.repo / ".git")
        result = self.run_index(expected=1)
        self.assertIn("无法读取 Git 暂存区", result.stderr)
        self.assertEqual(before, (self.repo / "reports/index.json").read_bytes())

    def test_chinese_git_date_is_independent_of_quote_path_config(self):
        self.run_index()
        self.assertEqual(self.items()[0]["date"], "2026-09-30")
        self.assertEqual(self.items()[0]["date_source"], "git")


if __name__ == "__main__":
    unittest.main()
