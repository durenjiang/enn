export type SystemConfigCategory =
  | 'base'
  | 'data_source'
  | 'ai_model'
  | 'notification'
  | 'system'
  | 'agent'
  | 'backtest'
  | 'uncategorized';

export type SystemConfigDataType =
  | 'string'
  | 'integer'
  | 'number'
  | 'boolean'
  | 'array'
  | 'json'
  | 'time';

export type SystemConfigUIControl =
  | 'text'
  | 'password'
  | 'number'
  | 'select'
  | 'textarea'
  | 'switch'
  | 'time';

export interface SystemConfigOption {
  label: string;
  value: string;
}

export interface SystemConfigDocLink {
  label: string;
  href: string;
}

export interface SystemConfigFieldSchema {
  key: string;
  title?: string;
  description?: string;
  category: SystemConfigCategory;
  dataType: SystemConfigDataType;
  uiControl: SystemConfigUIControl;
  isSensitive: boolean;
  isRequired: boolean;
  isEditable: boolean;
  defaultValue?: string | null;
  options: Array<string | SystemConfigOption>;
  validation: Record<string, unknown>;
  displayOrder: number;
  helpKey?: string | null;
  examples?: string[];
  docs?: SystemConfigDocLink[];
  warningCodes?: string[];
}

export interface SystemConfigCategorySchema {
  category: SystemConfigCategory;
  title: string;
  description?: string;
  displayOrder: number;
  fields: SystemConfigFieldSchema[];
}

export interface SystemConfigSchemaResponse {
  schemaVersion: string;
  categories: SystemConfigCategorySchema[];
}

export interface SystemConfigItem {
  key: string;
  value: string;
  rawValueExists: boolean;
  isMasked: boolean;
  schema?: SystemConfigFieldSchema;
}

export interface SystemConfigResponse {
  configVersion: string;
  maskToken: string;
  items: SystemConfigItem[];
  llmModelProviders?: string[];
  updatedAt?: string;
}

export interface SetupStatusCheck {
  key: string;
  title: string;
  category: 'base' | 'ai_model' | 'agent' | 'notification' | 'system';
  required: boolean;
  status: 'configured' | 'inherited' | 'optional' | 'needs_action';
  message: string;
  nextStep?: string | null;
}

export interface SetupStatusResponse {
  isComplete: boolean;
  readyForSmoke: boolean;
  requiredMissingKeys: string[];
  nextStepKey?: string | null;
  checks: SetupStatusCheck[];
}

export type GenerationBackendHealthStatus = 'not_tested' | 'passed' | 'failed' | 'skipped';
export type GenerationBackendSmokeMode = 'text' | 'json';

export interface GenerationBackendStatus {
  backendId: string;
  backendType: 'litellm' | 'local_cli';
  providerId: string;
  available: boolean;
  healthStatus: GenerationBackendHealthStatus;
  supportsJson: boolean;
  supportsTools: boolean;
  supportsStream: boolean;
  supportsVision: boolean;
  isPrimary: boolean;
  fallbackTarget?: string | null;
  maxConcurrency: number;
  usageAvailable: boolean;
  lastErrorCode?: string | null;
  lastErrorMessage?: string | null;
}

export interface GenerationBackendStatusResponse {
  primaryBackendId: string;
  fallbackBackendId?: string | null;
  primary: GenerationBackendStatus;
  fallback?: GenerationBackendStatus | null;
  backends: GenerationBackendStatus[];
}

export interface ExportSystemConfigResponse {
  content: string;
  configVersion: string;
  updatedAt?: string;
}

export interface SystemConfigUpdateItem {
  key: string;
  value: string;
}

export interface GenerationBackendStatusPreviewRequest {
  items?: SystemConfigUpdateItem[];
  maskToken?: string;
}

export interface TestGenerationBackendRequest {
  backendId?: string | null;
  mode?: GenerationBackendSmokeMode;
  items?: SystemConfigUpdateItem[];
  maskToken?: string;
  timeoutSeconds?: number | null;
}

export interface TestGenerationBackendResponse {
  success: boolean;
  mode: GenerationBackendSmokeMode;
  message: string;
  status: GenerationBackendStatus;
}

export interface AgentBackendStatusResponse {
  backend: string;
  available: boolean;
  experimental: boolean;
  version?: string | null;
  errorCode?: string | null;
  message?: string | null;
}

export interface AgentBackendStatusPreviewRequest {
  items?: SystemConfigUpdateItem[];
  maskToken?: string;
}

export interface UpdateSystemConfigRequest {
  configVersion: string;
  maskToken?: string;
  reloadNow?: boolean;
  items: SystemConfigUpdateItem[];
}

export interface UpdateSystemConfigResponse {
  success: boolean;
  configVersion: string;
  appliedCount: number;
  skippedMaskedCount: number;
  reloadTriggered: boolean;
  updatedKeys: string[];
  warnings: string[];
}

export interface ValidateSystemConfigRequest {
  items: SystemConfigUpdateItem[];
}

export interface ImportSystemConfigRequest {
  configVersion: string;
  content: string;
  reloadNow?: boolean;
}

export interface ConfigValidationIssue {
  key: string;
  code: string;
  message: string;
  severity: 'error' | 'warning';
  expected?: string;
  actual?: string;
}

export interface ValidateSystemConfigResponse {
  valid: boolean;
  issues: ConfigValidationIssue[];
}

export interface SchedulerStatusResponse {
  enabled: boolean;
  running: boolean;
  scheduleTimes: string[];
  nextRunAt?: string | null;
  lastRunAt?: string | null;
  lastSuccessAt?: string | null;
  lastError?: string | null;
  lastSkippedAt?: string | null;
  lastSkipReason?: string | null;
}

export interface SchedulerRunNowResponse {
  accepted: boolean;
  running: boolean;
  reason?: string;
}

export interface TestLLMChannelRequest {
  name: string;
  protocol: string;
  apiSurface?: LLMApiSurface;
  baseUrl?: string;
  apiKey?: string;
  models: string[];
  enabled?: boolean;
  timeoutSeconds?: number;
  capabilityChecks?: LLMCapabilityCheck[];
  useSavedSecret?: boolean;
}

export type LLMApiSurface = 'chat_completions' | 'responses';

export type LLMCapabilityCheck = 'json' | 'tools' | 'vision' | 'stream';

export interface LLMCapabilityCheckResult {
  status: 'passed' | 'failed' | 'skipped';
  message: string;
  errorCode?: string | null;
  stage: string;
  retryable?: boolean | null;
  latencyMs?: number | null;
  details?: Record<string, unknown>;
}

export interface TestLLMChannelResponse {
  success: boolean;
  message: string;
  error?: string | null;
  errorCode?: string | null;
  stage?: string | null;
  retryable?: boolean | null;
  details?: Record<string, unknown>;
  resolvedProtocol?: string | null;
  resolvedApiSurface?: LLMApiSurface | null;
  resolvedModel?: string | null;
  latencyMs?: number | null;
  capabilityResults?: Partial<Record<LLMCapabilityCheck, LLMCapabilityCheckResult>>;
}

export type NotificationTestChannel =
  | 'wechat'
  | 'feishu'
  | 'dingtalk'
  | 'telegram'
  | 'email'
  | 'pushover'
  | 'ntfy'
  | 'gotify'
  | 'pushplus'
  | 'serverchan3'
  | 'custom'
  | 'discord'
  | 'slack'
  | 'astrbot';

export interface NotificationTestAttempt {
  channel: NotificationTestChannel;
  success: boolean;
  message: string;
  target?: string | null;
  errorCode?: string | null;
  stage: string;
  retryable: boolean;
  latencyMs?: number | null;
  httpStatus?: number | null;
}

export interface TestNotificationChannelRequest {
  channel: NotificationTestChannel;
  items?: SystemConfigUpdateItem[];
  maskToken?: string;
  title?: string;
  content?: string;
  timeoutSeconds?: number;
}

export interface TestNotificationChannelResponse {
  success: boolean;
  message: string;
  errorCode?: string | null;
  stage?: string | null;
  retryable: boolean;
  latencyMs?: number | null;
  attempts: NotificationTestAttempt[];
}

export interface DiscoverLLMChannelModelsRequest {
  name: string;
  protocol: string;
  baseUrl?: string;
  apiKey?: string;
  models?: string[];
  timeoutSeconds?: number;
  useSavedSecret?: boolean;
}

export interface DiscoverLLMChannelModelsResponse {
  success: boolean;
  message: string;
  error?: string | null;
  errorCode?: string | null;
  stage?: string | null;
  retryable?: boolean | null;
  details?: Record<string, unknown>;
  resolvedProtocol?: string | null;
  models: string[];
  latencyMs?: number | null;
}

export interface SystemConfigValidationErrorResponse {
  error: string;
  message: string;
  issues: ConfigValidationIssue[];
}

export interface SystemConfigConflictResponse {
  error: string;
  message: string;
  currentConfigVersion: string;
}
