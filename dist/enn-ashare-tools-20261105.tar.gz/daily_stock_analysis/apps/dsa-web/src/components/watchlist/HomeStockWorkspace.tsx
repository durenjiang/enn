import type React from 'react';
import { useId, useMemo, useState } from 'react';
import {
  ArrowDownWideNarrow,
  CalendarDays,
  CheckCircle2,
  CircleAlert,
  Clock3,
  Loader2,
  Play,
  Plus,
  RefreshCw,
  Star,
  Trash2,
} from 'lucide-react';
import { Badge, Button, InlineAlert, Input, ScrollArea, StatusDot } from '../common';
import { DashboardPanelHeader, DashboardStateBlock } from '../dashboard';
import { StockBar } from '../history';
import type { StockBarItem, TaskInfo } from '../../types/analysis';
import { getSentimentColor } from '../../types/analysis';
import { buildDecisionActionLabelMap, getDecisionActionLabel } from '../../utils/decisionAction';
import { formatDateTime } from '../../utils/format';
import { areAssetAwareCodesEquivalent, toAssetAwareCodeKey, type AssetAwareAssetType } from '../../utils/stockCode';
import { truncateStockName } from '../../utils/stockName';
import { useUiLanguage } from '../../contexts/UiLanguageContext';
import type { UiTextKey, UiTextParams } from '../../i18n/uiText';
import { isWatchlistRowPendingAnalysis } from './watchlistRowState';

export type HomeWorkspaceTab = 'watchlist' | 'today' | 'history';
export type WatchlistAnalyzeMode = 'all' | 'pending';

export interface HomeWatchlistRow {
  code: string;
  assetType?: AssetAwareAssetType;
  /**
   * Asset-aware identity key already resolved by HomePage from the stock index
   * registry (canonical for registered indices, e.g. `sh000016` for a raw
   * watchlist string `000016.SH`). Row-selection compares against this key
   * FIRST instead of re-parsing the raw alias, so a canonical selected report
   * always selects its own alias-form row and never a same-code stock row.
   */
  identityKey?: string;
  latestItem?: StockBarItem;
  analyzedToday: boolean;
  isTodayStatusLoading?: boolean;
  isTodayStatusUnknown?: boolean;
  activeTask?: TaskInfo;
}

interface BatchStatus {
  variant: 'success' | 'warning' | 'danger';
  message: string;
}

type WatchlistSignalTone = 'success' | 'warning' | 'danger' | 'info' | 'neutral';

interface WatchlistSignal {
  label: string;
  value: string;
  tone: WatchlistSignalTone;
  pulse?: boolean;
}

interface WatchlistRowSignals {
  change: WatchlistSignal;
  state: WatchlistSignal;
  nextAction: WatchlistSignal;
}

function buildSignalDescription(
  signals: WatchlistSignal[],
  t: (key: UiTextKey, params?: UiTextParams) => string,
) {
  return signals
    .map((signal) => t('watchlist.signalSummaryItem', { label: signal.label, value: signal.value }))
    .join(t('watchlist.signalSummarySeparator'));
}

interface HomeStockWorkspaceProps {
  activeTab: HomeWorkspaceTab;
  onTabChange: (tab: HomeWorkspaceTab) => void;
  watchlistRows: HomeWatchlistRow[];
  watchlistLoading: boolean;
  watchlistActioning: boolean;
  watchlistMessage: string | null;
  onAddToWatchlist: (code: string) => Promise<void>;
  onRemoveFromWatchlist: (code: string) => Promise<void>;
  onRefreshWatchlist: () => Promise<void>;
  onAnalyzeWatchlist: (mode: WatchlistAnalyzeMode) => Promise<void>;
  isBatchAnalyzing: boolean;
  batchStatus: BatchStatus | null;
  todayItems: StockBarItem[];
  isLoadingTodayItems: boolean;
  todayLoadError: boolean;
  watchlistAnalyzedTodayCount: number;
  historyItems: StockBarItem[];
  isLoadingHistory: boolean;
  selectedStockCode?: string;
  selectedAssetType?: AssetAwareAssetType | null;
  selectedRecordId?: number;
  onHistoryItemClick: (recordId: number) => void;
  onDeleteStock?: (stockCode: string) => Promise<void> | void;
  isDeleting?: boolean;
  className?: string;
}

function getTaskStatusLabel(task: TaskInfo | undefined, t: (key: UiTextKey, params?: UiTextParams) => string) {
  if (!task) return '';
  if (task.status === 'processing') return t('taskPanel.processing');
  if (task.status === 'pending') return t('taskPanel.pending');
  if (task.status === 'cancel_requested') return t('taskPanel.cancelRequested');
  return task.status;
}

function buildWatchlistRowSignals({
  row,
  canOpenDetail,
  isLatestDetailLoading,
  isLatestDetailUnavailable,
  taskLabel,
  t,
}: {
  row: HomeWatchlistRow;
  canOpenDetail: boolean;
  isLatestDetailLoading: boolean;
  isLatestDetailUnavailable: boolean;
  taskLabel: string;
  t: (key: UiTextKey, params?: UiTextParams) => string;
}): WatchlistRowSignals {
  let change: Omit<WatchlistSignal, 'label'>;
  let state: Omit<WatchlistSignal, 'label'>;
  let nextAction: Omit<WatchlistSignal, 'label'>;

  if (isLatestDetailLoading) {
    change = { value: t('watchlist.changeLoading'), tone: 'info', pulse: true };
    state = { value: t('watchlist.stateLoading'), tone: 'info', pulse: true };
    nextAction = { value: t('watchlist.nextWaitStatus'), tone: 'info', pulse: true };
  } else if (isLatestDetailUnavailable) {
    change = { value: t('watchlist.changeUnknown'), tone: 'warning' };
    state = { value: t('watchlist.stateUnknown'), tone: 'warning' };
    nextAction = { value: t('watchlist.nextRefresh'), tone: 'warning' };
  } else {
    if (row.analyzedToday) {
      change = { value: t('watchlist.changeAnalyzedToday'), tone: 'success' };
      state = { value: t('watchlist.stateAnalyzed'), tone: 'success' };
      nextAction = {
        value: canOpenDetail ? t('watchlist.nextOpenLatest') : t('watchlist.nextRefresh'),
        tone: canOpenDetail ? 'success' : 'warning',
      };
    } else if (row.latestItem) {
      change = { value: t('watchlist.changeHasLatest'), tone: 'info' };
      state = { value: t('watchlist.statePending'), tone: 'warning' };
      nextAction = { value: t('watchlist.nextAnalyze'), tone: 'warning' };
    } else {
      change = { value: t('watchlist.changeNoReport'), tone: 'neutral' };
      state = { value: t('watchlist.statePending'), tone: 'warning' };
      nextAction = { value: t('watchlist.nextAnalyze'), tone: 'warning' };
    }
  }

  if (row.activeTask) {
    state = {
      value: t('watchlist.stateTask', { status: taskLabel }),
      tone: row.activeTask.status === 'processing' ? 'info' : 'neutral',
      pulse: row.activeTask.status === 'processing',
    };
    nextAction = {
      value: t('watchlist.nextWaitTask'),
      tone: row.activeTask.status === 'processing' ? 'info' : 'neutral',
      pulse: row.activeTask.status === 'processing',
    };
  }

  return {
    change: { label: t('watchlist.change'), ...change },
    state: { label: t('watchlist.state'), ...state },
    nextAction: { label: t('watchlist.nextAction'), ...nextAction },
  };
}

function rowHasSelectedIdentity(
  row: HomeWatchlistRow,
  selectedStockCode: string | null | undefined,
  selectedAssetType: AssetAwareAssetType | null | undefined,
): boolean {
  // The registry-derived canonical identity (HomePage) wins: an alias-form raw
  // watchlist code (e.g. `000016.SH`) whose identityKey is `sh000016` must
  // match the canonical selected report without re-parsing the raw alias, and
  // must never fold with the bare `000016` stock row.
  if (row.identityKey) {
    return toAssetAwareCodeKey(selectedStockCode, selectedAssetType) === row.identityKey;
  }
  return areAssetAwareCodesEquivalent(selectedStockCode, selectedAssetType, row.code, row.assetType);
}

const ScoreBadge: React.FC<{ item?: StockBarItem }> = ({ item }) => {
  const { t } = useUiLanguage();
  const score = typeof item?.sentimentScore === 'number' ? item.sentimentScore : null;
  const color = score !== null ? getSentimentColor(score) : null;
  if (score === null || !color) {
    return <span className="text-[11px] text-muted-text">{t('common.noData')}</span>;
  }

  const actionLabels = buildDecisionActionLabelMap(t);
  const operationLabel = getDecisionActionLabel(
    item?.action,
    item?.actionLabel,
    item?.operationAdvice,
    t('history.sentiment'),
    actionLabels,
  );

  return (
    <Badge
      variant="default"
      size="sm"
      className="shrink-0 shadow-none text-[11px] font-semibold leading-none"
      style={{
        color,
        borderColor: `${color}30`,
        backgroundColor: `${color}10`,
      }}
    >
      {operationLabel} {score}
    </Badge>
  );
};

const WatchlistSignalCell: React.FC<{ signal: WatchlistSignal }> = ({ signal }) => (
  <span className="min-w-0 rounded-lg border border-subtle bg-base/35 px-2 py-1.5">
    <span className="block text-[10px] font-medium text-muted-text">
      {signal.label}
    </span>
    <span className="mt-1 flex min-w-0 items-start gap-1.5 text-[11px] font-medium text-secondary-text">
      <StatusDot tone={signal.tone} pulse={signal.pulse} className="h-1.5 w-1.5" />
      <span className="min-w-0 whitespace-normal break-words leading-snug">{signal.value}</span>
    </span>
  </span>
);

const WatchlistRowItem: React.FC<{
  row: HomeWatchlistRow;
  onRemove: (code: string) => Promise<void>;
  onOpenDetail: (row: HomeWatchlistRow) => void;
  disabled: boolean;
  selected: boolean;
}> = ({ row, onRemove, onOpenDetail, disabled, selected }) => {
  const { t } = useUiLanguage();
  const signalDescriptionId = useId();
  const taskLabel = getTaskStatusLabel(row.activeTask, t);
  const isLatestDetailLoading = Boolean(row.isTodayStatusLoading);
  const isLatestDetailUnavailable = !isLatestDetailLoading && Boolean(row.isTodayStatusUnknown);
  const item = isLatestDetailLoading || isLatestDetailUnavailable ? undefined : row.latestItem;
  const stockName = row.latestItem?.stockName || row.code;
  const canOpenDetail = typeof item?.id === 'number';
  const signals = buildWatchlistRowSignals({
    row,
    canOpenDetail,
    isLatestDetailLoading,
    isLatestDetailUnavailable,
    taskLabel,
    t,
  });
  const signalDescription = buildSignalDescription([signals.change, signals.state, signals.nextAction], t);

  const handleOpenDetail = () => {
    onOpenDetail(row);
  };

  return (
    <div
      className={`home-subpanel group grid min-w-0 grid-cols-[minmax(0,1fr)_auto] gap-2 px-3 py-2.5 text-left transition-colors ${
        selected
          ? 'border-primary/35 bg-primary/10'
          : 'hover:border-subtle-hover hover:bg-base/65'
      }`}
      data-testid={`watchlist-row-${row.code}`}
    >
      <button
        type="button"
        aria-pressed={selected}
        aria-label={canOpenDetail
          ? t('watchlist.openLatestDetailAria', { code: row.code })
          : isLatestDetailLoading
            ? t('watchlist.latestDetailLoadingAria', { code: row.code })
            : isLatestDetailUnavailable
              ? t('watchlist.latestDetailUnavailableAria', { code: row.code })
            : t('watchlist.noLatestDetailAria', { code: row.code })}
        aria-describedby={signalDescriptionId}
        className="grid min-w-0 cursor-pointer gap-2 rounded-lg text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/30"
        onClick={handleOpenDetail}
      >
        <span id={signalDescriptionId} className="sr-only">
          {signalDescription}
        </span>
        <div className="min-w-0">
          <div className="flex min-w-0 items-center gap-2">
            <span className="truncate text-sm font-semibold text-foreground">
              {truncateStockName(stockName)}
            </span>
            {row.isTodayStatusLoading ? (
              <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-muted-text" aria-label={t('watchlist.todayStatusLoading')} />
            ) : row.isTodayStatusUnknown ? (
              <CircleAlert className="h-3.5 w-3.5 shrink-0 text-warning" aria-label={t('watchlist.todayStatusUnavailable')} />
            ) : row.analyzedToday ? (
              <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-success" aria-label={t('watchlist.analyzedToday')} />
            ) : (
              <Clock3 className="h-3.5 w-3.5 shrink-0 text-muted-text" aria-label={t('watchlist.notAnalyzedToday')} />
            )}
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <span className="font-mono text-[11px] text-secondary-text">{row.code}</span>
            {item?.lastAnalysisTime ? (
              <>
                <span className="h-1 w-1 rounded-full bg-subtle-hover" />
                <span className="text-[11px] text-muted-text">{formatDateTime(item.lastAnalysisTime)}</span>
              </>
            ) : null}
          </div>
          <div className="flex min-w-0 items-center justify-between gap-2 text-[11px]">
            <span className={`truncate ${canOpenDetail ? 'text-primary' : isLatestDetailLoading ? 'text-muted-text' : 'text-warning'}`}>
              {canOpenDetail
                ? t('common.details')
                : isLatestDetailLoading
                  ? t('watchlist.latestDetailLoadingCta')
                  : isLatestDetailUnavailable
                    ? t('watchlist.latestDetailUnavailableCta')
                  : t('watchlist.noLatestDetailCta')}
            </span>
          </div>
          <div className="mt-2 grid min-w-0 grid-cols-1 gap-1.5">
            <WatchlistSignalCell signal={signals.change} />
            <WatchlistSignalCell signal={signals.state} />
            <WatchlistSignalCell signal={signals.nextAction} />
          </div>
          {row.activeTask ? (
            <div className="flex min-w-0 items-center gap-2 text-[11px] text-muted-text">
              <StatusDot
                tone={row.activeTask.status === 'processing' ? 'info' : 'neutral'}
                pulse={row.activeTask.status === 'processing'}
                className="h-1.5 w-1.5"
              />
              <span className="truncate">{t('watchlist.taskRunning', { status: taskLabel })}</span>
            </div>
          ) : null}
        </div>
      </button>
      <div className="flex shrink-0 items-start gap-1.5">
        <ScoreBadge item={item} />
        <Button
          type="button"
          variant="ghost"
          size="xsm"
          className="h-7 w-7 px-0"
          disabled={disabled}
          aria-label={t('watchlist.removeAria', { code: row.code })}
          onClick={() => void onRemove(row.code)}
        >
          <Trash2 className="h-3.5 w-3.5 text-danger" aria-hidden="true" />
        </Button>
      </div>
    </div>
  );
};

const TodayItem: React.FC<{ item: StockBarItem; onClick: (recordId: number) => void }> = ({ item, onClick }) => {
  const stockName = item.stockName || item.stockCode;

  return (
    <button
      type="button"
      className="home-subpanel grid w-full min-w-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-2 px-3 py-2.5 text-left"
      onClick={() => onClick(item.id)}
    >
      <div className="min-w-0">
        <span className="block truncate text-sm font-semibold text-foreground">
          {truncateStockName(stockName)}
        </span>
        <span className="mt-1 block truncate font-mono text-[11px] text-secondary-text">
          {item.stockCode}
        </span>
      </div>
      <ScoreBadge item={item} />
    </button>
  );
};

export const HomeStockWorkspace: React.FC<HomeStockWorkspaceProps> = ({
  activeTab,
  onTabChange,
  watchlistRows,
  watchlistLoading,
  watchlistActioning,
  watchlistMessage,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onRefreshWatchlist,
  onAnalyzeWatchlist,
  isBatchAnalyzing,
  batchStatus,
  todayItems,
  isLoadingTodayItems,
  todayLoadError,
  watchlistAnalyzedTodayCount,
  historyItems,
  isLoadingHistory,
  selectedStockCode,
  selectedAssetType,
  selectedRecordId,
  onHistoryItemClick,
  onDeleteStock,
  isDeleting = false,
  className = '',
}) => {
  const { t } = useUiLanguage();
  const [draftCode, setDraftCode] = useState('');
  // PR #2312: the notice carries the *triggering row's own* identity
  // (code + assetType). Reusing the candidate row's assetType for the notice
  // code would let an index row and a same-code stock row cross-match (e.g.
  // notice code ``000016.SH`` classified with the stock row's asset type folds
  // to stock ``000016`` and attaches to the wrong row).
  const [workspaceNotice, setWorkspaceNotice] = useState<{ code: string; assetType: AssetAwareAssetType } | null>(null);
  const pendingWatchlistCount = watchlistRows.filter(isWatchlistRowPendingAnalysis).length;
  const isTodayStatusUnavailable = watchlistRows.some((row) => row.isTodayStatusLoading || row.isTodayStatusUnknown);
  const topTodayItem = todayItems[0];
  const tabs: Array<{ key: HomeWorkspaceTab; label: string }> = [
    { key: 'history', label: t('watchlist.tabHistory') },
    { key: 'watchlist', label: t('watchlist.tabWatchlist') },
    { key: 'today', label: t('watchlist.tabToday') },
  ];

  const statusClassName = useMemo(() => {
    if (!batchStatus) return '';
    if (batchStatus.variant === 'danger') return 'border-danger/30 bg-danger/10 text-danger';
    if (batchStatus.variant === 'warning') return 'border-warning/30 bg-warning/10 text-warning';
    return 'border-success/30 bg-success/10 text-success';
  }, [batchStatus]);

  const visibleWorkspaceNotice = useMemo(() => {
    if (!workspaceNotice) return null;
    const row = watchlistRows.find(
      (item) => areAssetAwareCodesEquivalent(item.code, item.assetType, workspaceNotice.code, workspaceNotice.assetType),
    );
    if (!row) return null;
    if (row.isTodayStatusLoading) {
      return { message: t('watchlist.latestDetailLoading') };
    }
    if (row.isTodayStatusUnknown) {
      return { message: t('watchlist.latestDetailUnavailable') };
    }
    if (row.latestItem) return null;
    return { message: t('watchlist.noLatestDetail') };
  }, [t, watchlistRows, workspaceNotice]);

  const handleAddSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const code = draftCode.trim();
    if (!code) return;
    setWorkspaceNotice(null);
    void onAddToWatchlist(code).then(() => setDraftCode(''));
  };

  const handleWatchlistRowOpen = (row: HomeWatchlistRow) => {
    if (row.isTodayStatusLoading || row.isTodayStatusUnknown) {
      setWorkspaceNotice({ code: row.code, assetType: row.assetType ?? 'stock' });
      return;
    }
    const recordId = row.latestItem?.id;
    if (typeof recordId === 'number') {
      setWorkspaceNotice(null);
      onHistoryItemClick(recordId);
      return;
    }
    setWorkspaceNotice({ code: row.code, assetType: row.assetType ?? 'stock' });
  };

  const renderTabs = (
    <div className="grid grid-cols-3 gap-1 rounded-xl border border-subtle bg-base/40 p-1">
      {tabs.map((tab) => {
        const selected = activeTab === tab.key;
        return (
          <button
            key={tab.key}
            type="button"
            aria-pressed={selected}
            className={`h-8 rounded-lg px-2 text-xs font-medium transition-colors ${
              selected ? 'bg-primary/15 text-primary shadow-inner' : 'text-secondary-text hover:bg-hover hover:text-foreground'
            }`}
            onClick={() => {
              setWorkspaceNotice(null);
              onTabChange(tab.key);
            }}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );

  if (activeTab === 'history') {
    return (
      <div
        data-testid="home-stock-workspace"
        className={`home-stock-scroll-shell flex min-h-0 flex-1 flex-col gap-2 ${className}`}
      >
        {renderTabs}
        <StockBar
          items={historyItems}
          isLoading={isLoadingHistory}
          selectedStockCode={selectedStockCode}
          selectedRecordId={selectedRecordId}
          onItemClick={onHistoryItemClick}
          onDeleteStock={onDeleteStock}
          isDeleting={isDeleting}
          className="flex-1"
        />
      </div>
    );
  }

  return (
    <aside
      data-testid="home-stock-workspace"
      className={`glass-card home-stock-scroll-shell flex min-h-0 flex-1 flex-col ${className}`}
    >
      <div className="space-y-2.5 border-b border-subtle px-3 py-3 sm:px-4">
        {renderTabs}

        {activeTab === 'watchlist' ? (
          <>
            <DashboardPanelHeader
              className="mb-0"
              title={t('watchlist.title')}
              titleClassName="text-sm font-medium"
              leading={<Star className="h-4 w-4 text-primary" aria-hidden="true" />}
              actions={(
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-muted-text">{t('common.itemsCount', { count: watchlistRows.length })}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="xsm"
                    className="h-7 w-7 px-0"
                    disabled={watchlistLoading}
                    onClick={() => {
                      setWorkspaceNotice(null);
                      void onRefreshWatchlist();
                    }}
                    aria-label={t('watchlist.refreshAria')}
                  >
                    <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                  </Button>
                </div>
              )}
            />
            <div className="flex flex-wrap gap-1.5">
              <Badge variant="default" className="gap-1 shadow-none text-[11px]">
                {t('watchlist.todayCoverage')} {watchlistAnalyzedTodayCount}/{watchlistRows.length}
              </Badge>
              <Badge variant="default" className="gap-1 shadow-none text-[11px]">
                {t('watchlist.pendingToday')} {pendingWatchlistCount}
              </Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                size="sm"
                variant="home-action-ai"
                className="h-8 flex-1 whitespace-nowrap px-2 text-xs sm:flex-none"
                disabled={watchlistLoading || watchlistRows.length === 0 || isBatchAnalyzing}
                isLoading={isBatchAnalyzing}
                loadingText={t('watchlist.submitting')}
                onClick={() => void onAnalyzeWatchlist('all')}
              >
                <Play className="h-4 w-4" aria-hidden="true" />
                {t('watchlist.analyzeAll')}
              </Button>
              <Button
                type="button"
                size="sm"
                variant="home-action-report"
                className="h-8 flex-1 whitespace-nowrap px-2 text-xs sm:flex-none"
                disabled={watchlistLoading || pendingWatchlistCount === 0 || isTodayStatusUnavailable || isBatchAnalyzing}
                onClick={() => void onAnalyzeWatchlist('pending')}
              >
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                {t('watchlist.analyzePending')}
              </Button>
            </div>
            <form className="grid grid-cols-[minmax(0,1fr)_auto] gap-2" onSubmit={handleAddSubmit}>
              <Input
                value={draftCode}
                onChange={(event) => setDraftCode(event.target.value)}
                placeholder={t('watchlist.addPlaceholder')}
                className="h-8 rounded-lg px-3 text-xs"
                disabled={watchlistActioning}
                aria-label={t('watchlist.addPlaceholder')}
              />
              <Button
                type="submit"
                size="sm"
                variant="secondary"
                className="h-8 w-8 px-0"
                disabled={!draftCode.trim() || watchlistActioning}
                isLoading={watchlistActioning}
                aria-label={t('watchlist.add')}
              >
                <Plus className="h-4 w-4" aria-hidden="true" />
              </Button>
            </form>
            {batchStatus ? (
              <div className={`rounded-xl border px-3 py-2 text-xs ${statusClassName}`}>
                {batchStatus.message}
              </div>
            ) : null}
            {watchlistMessage ? (
              <div className="rounded-xl border border-subtle bg-base/35 px-3 py-2 text-xs text-secondary-text">
                {watchlistMessage}
              </div>
            ) : null}
            {visibleWorkspaceNotice ? (
              <InlineAlert
                variant="warning"
                message={visibleWorkspaceNotice.message}
                className="rounded-xl px-3 py-2 text-xs shadow-none"
              />
            ) : null}
          </>
        ) : (
          <>
            <DashboardPanelHeader
              className="mb-0"
              title={t('watchlist.todayTitle')}
              titleClassName="text-sm font-medium"
              leading={<CalendarDays className="h-4 w-4 text-cyan" aria-hidden="true" />}
              actions={<span className="text-[11px] text-muted-text">{t('common.itemsCount', { count: todayItems.length })}</span>}
            />
            <div className="flex flex-wrap gap-1.5">
              <Badge variant="default" className="gap-1 shadow-none text-[11px]">
                {t('watchlist.watchlistCoverage')} {watchlistAnalyzedTodayCount}/{watchlistRows.length}
              </Badge>
              <Badge variant="default" className="gap-1 shadow-none text-[11px]">
                {t('watchlist.topScore')} {topTodayItem?.sentimentScore ?? '-'}
              </Badge>
            </div>
          </>
        )}
      </div>

      <ScrollArea
        viewportClassName="px-3 py-3 sm:px-4 overscroll-y-contain touch-pan-y"
        className="min-h-0 flex-1"
        testId="home-stock-workspace-scroll"
      >
        {activeTab === 'watchlist' ? (
          watchlistLoading ? (
            <DashboardStateBlock loading compact title={t('watchlist.loading')} />
          ) : watchlistRows.length === 0 ? (
            <DashboardStateBlock
              compact
              title={t('watchlist.emptyTitle')}
              description={t('watchlist.emptyDescription')}
            />
          ) : (
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-[11px] text-muted-text">
                <ArrowDownWideNarrow className="h-3.5 w-3.5" aria-hidden="true" />
                {t('watchlist.listHint')}
              </div>
              {watchlistRows.map((row) => (
                <WatchlistRowItem
                  key={row.code}
                  row={row}
                  onRemove={async (code) => {
                    setWorkspaceNotice(null);
                    await onRemoveFromWatchlist(code);
                  }}
                  onOpenDetail={handleWatchlistRowOpen}
                  disabled={watchlistActioning}
                  selected={
                    (typeof selectedRecordId === 'number' && selectedRecordId === row.latestItem?.id)
                    || (
                      Boolean(selectedStockCode)
                      && (
                        rowHasSelectedIdentity(row, selectedStockCode, selectedAssetType)
                        || areAssetAwareCodesEquivalent(selectedStockCode ?? '', selectedAssetType, row.latestItem?.stockCode ?? '', row.latestItem?.assetType)
                      )
                    )
                  }
                />
              ))}
            </div>
          )
        ) : isLoadingTodayItems ? (
          <DashboardStateBlock loading compact title={t('watchlist.loading')} />
        ) : todayLoadError ? (
          <DashboardStateBlock
            compact
            title={t('watchlist.todayLoadErrorTitle')}
            description={t('watchlist.todayLoadErrorDescription')}
          />
        ) : todayItems.length === 0 ? (
          <DashboardStateBlock
            compact
            title={t('watchlist.todayEmptyTitle')}
            description={t('watchlist.todayEmptyDescription')}
          />
        ) : (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-[11px] text-muted-text">
              <ArrowDownWideNarrow className="h-3.5 w-3.5" aria-hidden="true" />
              {t('watchlist.todaySortHint')}
            </div>
            {todayItems.map((item) => (
              <TodayItem key={`${item.stockCode}-${item.id}`} item={item} onClick={onHistoryItemClick} />
            ))}
          </div>
        )}
      </ScrollArea>
    </aside>
  );
};

export default HomeStockWorkspace;
