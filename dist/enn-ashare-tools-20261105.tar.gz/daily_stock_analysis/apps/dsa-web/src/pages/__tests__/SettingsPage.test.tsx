import type React from 'react';
import { act, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { createMemoryRouter, RouterProvider, Outlet } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { resolveWebBuildInfo } from '../../utils/constants';
import { resetSharedDesktopUpdateState } from '../../desktop/updateStore';
import type { SetupStatusResponse } from '../../types/systemConfig';
import SettingsPage from '../SettingsPage';
import { DesktopUpdateIndicator } from '../../components/layout/DesktopUpdateIndicator';

function renderSettingsPage(initialEntries: string[] = ['/settings']) {
  const router = createMemoryRouter(
    [
      { path: '/settings', element: <SettingsPage /> },
      // The in-app "leaving /settings" target — kept minimal so the data
      // router has somewhere to navigate to on `proceed()` without mounting
      // the heavy lazy ChatPage. Marked with a testid so in-app navigation
      // tests can assert the destination actually rendered.
      { path: '/chat', element: <div data-testid="chat-page-stub" /> },
      // Stub for non-existent path so unknown-destination navigations don't
      // throw.
      { path: '*', element: <div data-testid="not-found-stub" /> },
    ],
    { initialEntries },
  );
  const utils = render(<RouterProvider router={router} />);
  // Trigger an in-router state refresh so memoised route element re-renders
  // after the mocked hook return value changes between iterations (the data
  // router keeps the <SettingsPage /> element reference stable across
  // rerenders, so React.memo would otherwise bail and the new mock return
  // value would not be re-read).
  const rerenderSettingsPage = () => {
    act(() => {
      router.revalidate();
    });
  };
  return { ...utils, router, rerender: rerenderSettingsPage, rerenderSettingsPage };
}

const {
  editorTestMode,
  analyzeAsync,
  exportEnv,
  getSchedulerStatus,
  getSetupStatus,
  importEnv,
  runSchedulerNow,
  updateSystemConfig,
  screeningEnable,
  notifyScreeningConfigChanged,
  notifySystemConfigChanged,
  desktopCheckForUpdates,
  desktopGetUpdateState,
  desktopInstallDownloadedUpdate,
  desktopOnUpdateStateChange,
  desktopOpenReleasePage,
  load,
  clearToast,
  setActiveCategory,
  save,
  resetDraft,
  setDraftValue,
  applyPartialUpdate,
  getChangedItems,
  refreshAfterExternalSave,
  refreshStatus,
  settingsPanelErrorBoundary,
  useAuthMock,
  useSystemConfigMock,
  webBuildInfoMock,
} = vi.hoisted(() => ({
  editorTestMode: { real: false },
  analyzeAsync: vi.fn(),
  exportEnv: vi.fn(),
  getSchedulerStatus: vi.fn(),
  getSetupStatus: vi.fn(),
  importEnv: vi.fn(),
  runSchedulerNow: vi.fn(),
  updateSystemConfig: vi.fn(),
  screeningEnable: vi.fn(),
  notifyScreeningConfigChanged: vi.fn(),
  notifySystemConfigChanged: vi.fn(),
  desktopCheckForUpdates: vi.fn(),
  desktopGetUpdateState: vi.fn(),
  desktopInstallDownloadedUpdate: vi.fn(),
  desktopOnUpdateStateChange: vi.fn(),
  desktopOpenReleasePage: vi.fn(),
  load: vi.fn(),
  clearToast: vi.fn(),
  setActiveCategory: vi.fn(),
  save: vi.fn(),
  resetDraft: vi.fn(),
  setDraftValue: vi.fn(),
  applyPartialUpdate: vi.fn(),
  getChangedItems: vi.fn(),
  refreshAfterExternalSave: vi.fn(),
  refreshStatus: vi.fn(),
  settingsPanelErrorBoundary: vi.fn(),
  useAuthMock: vi.fn(),
  useSystemConfigMock: vi.fn(),
  webBuildInfoMock: {
    version: '3.11.0',
    rawVersion: '3.11.0',
    revision: 'abc123def456',
    buildId: 'build-20260329-021530Z',
    buildTime: '2026-03-29T02:15:30.000Z',
    isFallbackVersion: false,
  },
}));

const mockedAnchorClick = vi.fn();

vi.mock('../../hooks', async () => {
  const actual = await vi.importActual<typeof import('../../hooks')>('../../hooks');
  return {
    ...actual,
    useAuth: () => useAuthMock(),
    useSystemConfig: () => useSystemConfigMock(),
  };
});

vi.mock('../../api/systemConfig', () => ({
  systemConfigApi: {
    exportEnv: (...args: unknown[]) => exportEnv(...args),
    getSchedulerStatus: (...args: unknown[]) => getSchedulerStatus(...args),
    getSetupStatus: (...args: unknown[]) => getSetupStatus(...args),
    importEnv: (...args: unknown[]) => importEnv(...args),
    runSchedulerNow: (...args: unknown[]) => runSchedulerNow(...args),
    update: (...args: unknown[]) => updateSystemConfig(...args),
  },
}));

vi.mock('../../api/analysis', () => ({
  analysisApi: {
    analyzeAsync: (...args: unknown[]) => analyzeAsync(...args),
  },
}));

vi.mock('../../api/screening', () => ({
  screeningApi: {
    enable: (...args: unknown[]) => screeningEnable(...args),
  },
  notifyScreeningConfigChanged: (...args: unknown[]) => notifyScreeningConfigChanged(...args),
  notifySystemConfigChanged: (...args: unknown[]) => notifySystemConfigChanged(...args),
}));

vi.mock('../../utils/constants', async () => {
  const actual = await vi.importActual<typeof import('../../utils/constants')>('../../utils/constants');
  return {
    ...actual,
    WEB_BUILD_INFO: webBuildInfoMock,
  };
});

vi.mock('../../components/settings', async () => {
  const { LLMChannelEditor: RealLLMChannelEditor } = await vi.importActual<typeof import('../../components/settings/LLMChannelEditor')>('../../components/settings/LLMChannelEditor');
  return ({
  AuthSettingsCard: () => <div>认证与登录保护</div>,
  ChangePasswordCard: () => <div>修改密码</div>,
  IntelligentImport: ({ onMerged }: { onMerged: (value: string) => void }) => (
    <button type="button" onClick={() => onMerged('SZ000001,SZ000002')}>
      merge stock list
    </button>
  ),
  LLMChannelEditor: ({
    items,
    onSaved,
    onDraftItemsChange,
    onDirtyChange,
    ...rest
  }: {
    items: Array<{ key: string; value: string }>;
    onSaved: (items: Array<{ key: string; value: string }>) => void;
    onDraftItemsChange?: (items: Array<{ key: string; value: string }>) => void;
    onDirtyChange?: (dirty: boolean) => void;
    onSavingChange?: (saving: boolean) => void;
    configVersion: string;
    maskToken: string;
    draftResetToken: number;
  }) => editorTestMode.real ? (
    <RealLLMChannelEditor items={items} onSaved={onSaved} onDraftItemsChange={onDraftItemsChange} onDirtyChange={onDirtyChange} {...rest} />
  ) : (
    <div>
      <button onClick={() => onDirtyChange?.(true)}>edit incomplete llm draft</button>
      <button onClick={() => onDirtyChange?.(false)}>restore llm draft</button>
      <div data-testid="llm-channel-editor-items">{items.map((item) => item.key).join(',')}</div>
      <button
        type="button"
        onClick={() => onDraftItemsChange?.([
          { key: 'LLM_CHANNELS', value: 'draft,backup' },
          { key: 'LLM_DRAFT_API_SURFACE', value: 'responses' },
          { key: 'LITELLM_MODEL', value: 'openai/draft-model' },
          { key: 'GENERATION_BACKEND', value: 'codex_cli' },
        ])}
      >
        emit llm draft
      </button>
      <button
        type="button"
        onClick={() => onSaved([{ key: 'LLM_CHANNELS', value: 'primary,backup' }])}
      >
        save llm channels
      </button>
    </div>
  ),
  GenerationBackendStatusPanel: ({ items }: { items: Array<{ key: string; value: string }> }) => (
    <div data-testid="generation-backend-status-items">
      {items.map((item) => `${item.key}=${item.value}`).join('|')}
    </div>
  ),
  AgentBackendStatusPanel: ({
    items,
    selectedBackend,
  }: {
    items: Array<{ key: string; value: string }>;
    selectedBackend: string;
  }) => (
    <div data-testid="agent-backend-status-panel-mock">
      <span data-testid="agent-backend-status-items">
        {items.map((item) => `${item.key}=${item.value}`).join('|')}
      </span>
      <span>{selectedBackend}</span>
    </div>
  ),
  NotificationTestPanel: ({ items }: { items: Array<{ key: string; value: string }> }) => (
    <div>通知测试面板:{items.map((item) => item.key).join(',')}</div>
  ),
  SettingsAlert: ({
    title,
    message,
    actionLabel,
    onAction,
  }: {
    title: string;
    message: string;
    actionLabel?: string;
    onAction?: () => void;
  }) => (
    <div>
      {title}:{message}
      {actionLabel ? (
        <button type="button" onClick={onAction}>
          {actionLabel}
        </button>
      ) : null}
    </div>
  ),
  SettingsCategoryNav: ({
    categories,
    activeCategory,
    onSelect,
  }: {
    categories: Array<{ category: string; title: string }>;
    activeCategory: string;
    onSelect: (value: string) => void;
  }) => (
    <nav>
      {categories.map((category) => (
        <button
          key={category.category}
          type="button"
          aria-pressed={activeCategory === category.category}
          onClick={() => onSelect(category.category)}
        >
          {category.title}
        </button>
      ))}
    </nav>
  ),
  SettingsField: ({
    item,
    disabled,
    issues = [],
  }: {
    item: {
      key: string;
      schema?: {
        description?: string;
        options?: Array<string | { label: string; value: string }>;
      };
      };
    disabled?: boolean;
    issues?: Array<{ code: string; message: string }>;
  }) => (
    <div
      data-testid={`settings-field-${item.key}`}
      data-disabled={disabled ? 'true' : 'false'}
      data-issues={issues.map((issue) => issue.code).join(',')}
    >
      <div>{item.key}</div>
      <textarea id={`setting-${item.key}`} readOnly />
      {item.schema?.description ? <p>{item.schema.description}</p> : null}
      {item.schema?.options?.map((option) => {
        const label = typeof option === 'string' ? option : option.label;
        const value = typeof option === 'string' ? option : option.value;
        return <span key={`${item.key}-${value}`}>{label}</span>;
      })}
    </div>
  ),
  SettingsLoading: () => <div>loading</div>,
  SettingsPanelErrorBoundary: ({
    title,
    diagnosticHint,
    children,
  }: {
    title: string;
    diagnosticHint?: React.ReactNode;
    children: React.ReactNode;
  }) => {
    settingsPanelErrorBoundary(title);
    return (
      <>
        {diagnosticHint ? <div>{diagnosticHint}</div> : null}
        {children}
      </>
    );
  },
  SettingsSectionCard: ({
    title,
    description,
    children,
  }: {
    title: string;
    description?: string;
    children: React.ReactNode;
  }) => (
    <section>
      <h2>{title}</h2>
      {description ? <p>{description}</p> : null}
      {children}
    </section>
  ),
});
});

function createDesktopRuntime(overrides: Record<string, unknown> = {}) {
  return {
    version: '3.12.0',
    getUpdateState: desktopGetUpdateState,
    checkForUpdates: desktopCheckForUpdates,
    installDownloadedUpdate: desktopInstallDownloadedUpdate,
    openReleasePage: desktopOpenReleasePage,
    onUpdateStateChange: desktopOnUpdateStateChange,
    ...overrides,
  };
}

const baseCategories = [
  { category: 'system', title: 'System', description: '系统设置', displayOrder: 1, fields: [] },
  { category: 'base', title: 'Base', description: '基础配置', displayOrder: 2, fields: [] },
  { category: 'ai_model', title: 'AI', description: '模型配置', displayOrder: 3, fields: [] },
  { category: 'notification', title: 'Notification', description: '通知配置', displayOrder: 4, fields: [] },
  { category: 'agent', title: 'Agent', description: 'Agent 配置', displayOrder: 5, fields: [] },
];

type ConfigState = {
  categories: Array<{ category: string; title: string; description: string; displayOrder: number; fields: [] }>;
  itemsByCategory: Record<string, Array<Record<string, unknown>>>;
  issueByKey: Record<string, unknown[]>;
  activeCategory: string;
  setActiveCategory: typeof setActiveCategory;
  hasDirty: boolean;
  dirtyCount: number;
  toast: null;
  clearToast: typeof clearToast;
  isLoading: boolean;
  isSaving: boolean;
  loadError: null;
  saveError: null;
  retryAction: null;
  load: typeof load;
  retry: ReturnType<typeof vi.fn>;
  save: typeof save;
  resetDraft: typeof resetDraft;
  setDraftValue: typeof setDraftValue;
  applyPartialUpdate: typeof applyPartialUpdate;
  getChangedItems: () => Array<{ key: string; value: string }>;
  refreshAfterExternalSave: typeof refreshAfterExternalSave;
  configVersion: string;
  maskToken: string;
};

type ConfigOverride = Partial<ConfigState>;

function buildSystemConfigState(overrides: ConfigOverride = {}) {
  return {
    categories: baseCategories,
    itemsByCategory: {
      system: [
        {
          key: 'ADMIN_AUTH_ENABLED',
          value: 'true',
          rawValueExists: true,
          isMasked: false,
          schema: {
            key: 'ADMIN_AUTH_ENABLED',
            category: 'system',
            dataType: 'boolean',
            uiControl: 'switch',
            isSensitive: false,
            isRequired: false,
            isEditable: true,
            options: [],
            validation: {},
            displayOrder: 1,
          },
        },
      ],
      base: [
        {
          key: 'STOCK_LIST',
          value: 'SH600000',
          rawValueExists: true,
          isMasked: false,
          schema: {
            key: 'STOCK_LIST',
            category: 'base',
            dataType: 'string',
            uiControl: 'textarea',
            isSensitive: false,
            isRequired: false,
            isEditable: true,
            options: [],
            validation: {},
            displayOrder: 1,
          },
        },
      ],
      ai_model: [
        {
          key: 'LLM_CHANNELS',
          value: 'primary',
          rawValueExists: true,
          isMasked: false,
          schema: {
            key: 'LLM_CHANNELS',
            category: 'ai_model',
            dataType: 'string',
            uiControl: 'textarea',
            isSensitive: false,
            isRequired: false,
            isEditable: true,
            options: [],
            validation: {},
            displayOrder: 1,
          },
        },
      ],
      agent: [
        {
          key: 'AGENT_ORCHESTRATOR_TIMEOUT_S',
          value: '600',
          rawValueExists: true,
          isMasked: false,
          schema: {
            key: 'AGENT_ORCHESTRATOR_TIMEOUT_S',
            category: 'agent',
            dataType: 'integer',
            uiControl: 'number',
            isSensitive: false,
            isRequired: false,
            isEditable: true,
            options: [],
            validation: {},
            displayOrder: 1,
          },
        },
      ],
      notification: [
        {
          key: 'WECHAT_WEBHOOK_URL',
          value: 'https://qyapi.example.com/hook',
          rawValueExists: true,
          isMasked: false,
          schema: {
            key: 'WECHAT_WEBHOOK_URL',
            category: 'notification',
            dataType: 'string',
            uiControl: 'password',
            isSensitive: true,
            isRequired: false,
            isEditable: true,
            options: [],
            validation: {},
            displayOrder: 1,
          },
        },
      ],
    },
    issueByKey: {},
    activeCategory: 'system',
    setActiveCategory,
    hasDirty: false,
    dirtyCount: 0,
    toast: null,
    clearToast,
    isLoading: false,
    isSaving: false,
    loadError: null,
    saveError: null,
    retryAction: null,
    load,
    retry: vi.fn(),
    save,
    resetDraft,
    setDraftValue,
    applyPartialUpdate,
    getChangedItems: () => [],
    refreshAfterExternalSave,
    configVersion: 'v1',
    maskToken: '******',
    ...overrides,
  };
}

function buildAgentItem(
  key: string,
  value: string,
  displayOrder: number,
  uiControl: 'select' | 'number' | 'text' = 'text',
) {
  return {
    key,
    value,
    rawValueExists: true,
    isMasked: false,
    schema: {
      key,
      category: 'agent',
      dataType: uiControl === 'number' ? 'integer' : 'string',
      uiControl,
      isSensitive: false,
      isRequired: false,
      isEditable: true,
      options: uiControl === 'select' ? [] : [],
      validation: {},
      displayOrder,
    },
  };
}

function createDeferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (reason?: unknown) => void;
  const promise = new Promise<T>((promiseResolve, promiseReject) => {
    resolve = promiseResolve;
    reject = promiseReject;
  });
  return { promise, resolve, reject };
}


function renderDesktopUpdateEntries(lateMount = false) {
  const router = createMemoryRouter([{
    element: <><DesktopUpdateIndicator /><Outlet /></>,
    children: [
      { path: '/header', element: null },
      { path: '/settings', element: <SettingsPage /> },
    ],
  }], { initialEntries: [lateMount ? '/header' : '/settings'] });
  return { ...render(<RouterProvider router={router} />), router };
}

function hangDesktopUpdateCheck() {
  let resolveCheck: ((value: unknown) => void) | undefined;
  desktopCheckForUpdates.mockImplementation(
    () => new Promise((resolve) => {
      resolveCheck = resolve;
    }),
  );
  return {
    async finish(value: unknown) {
      await act(async () => {
        resolveCheck?.(value);
      });
    },
  };
}

describe('SettingsPage', () => {
  beforeEach(() => {
    editorTestMode.real = false;
    vi.restoreAllMocks();
    vi.clearAllMocks();
    Object.assign(webBuildInfoMock, {
      version: '3.11.0',
      rawVersion: '3.11.0',
      revision: 'abc123def456',
      buildId: 'build-20260329-021530Z',
      buildTime: '2026-03-29T02:15:30.000Z',
      isFallbackVersion: false,
    });
    load.mockResolvedValue(true);
    exportEnv.mockResolvedValue({
      content: 'STOCK_LIST=600519\n',
      configVersion: 'v1',
      updatedAt: '2026-03-21T00:00:00Z',
    });
    getSchedulerStatus.mockResolvedValue({
      enabled: true,
      running: false,
      scheduleTimes: ['09:20', '15:10'],
      nextRunAt: '2026-06-21T09:20:00+08:00',
      lastRunAt: null,
      lastSuccessAt: null,
      lastError: null,
    });
    getSetupStatus.mockResolvedValue({
      isComplete: true,
      readyForSmoke: true,
      requiredMissingKeys: [],
      nextStepKey: null,
      checks: [
        {
          key: 'stock_list',
          title: '自选股',
          category: 'base',
          required: true,
          status: 'configured',
          message: '已配置自选股。',
          nextStep: null,
        },
        {
          key: 'llm_channels',
          title: '模型渠道',
          category: 'ai_model',
          required: true,
          status: 'configured',
          message: '已配置模型渠道。',
          nextStep: null,
        },
        {
          key: 'notification',
          title: '通知',
          category: 'notification',
          required: false,
          status: 'optional',
          message: '通知可选。',
          nextStep: null,
        },
      ],
    });
    analyzeAsync.mockResolvedValue({
      taskId: 'task-setup-smoke',
      status: 'pending',
      message: 'accepted',
    });
    runSchedulerNow.mockResolvedValue({
      accepted: true,
      running: true,
    });
    importEnv.mockResolvedValue({
      success: true,
      configVersion: 'v2',
      appliedCount: 1,
      skippedMaskedCount: 0,
      reloadTriggered: true,
      updatedKeys: ['STOCK_LIST'],
      warnings: [],
    });
    updateSystemConfig.mockResolvedValue({
      success: true,
      configVersion: 'v2',
      updatedKeys: ['SCREENING_ENABLED'],
      reloadTriggered: true,
    });
    screeningEnable.mockResolvedValue(undefined);
    desktopGetUpdateState.mockResolvedValue({
      status: 'idle',
      currentVersion: '3.12.0',
      latestVersion: '',
      message: '',
    });
    desktopCheckForUpdates.mockResolvedValue({
      status: 'up-to-date',
      currentVersion: '3.12.0',
      latestVersion: '3.12.0',
      message: '当前桌面端已是最新版本。',
    });
    desktopInstallDownloadedUpdate.mockResolvedValue(true);
    desktopOpenReleasePage.mockResolvedValue(true);
    desktopOnUpdateStateChange.mockImplementation(() => () => undefined);
    useAuthMock.mockReturnValue({
      authEnabled: true,
      passwordChangeable: true,
      refreshStatus,
    });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState());
    delete (window as { dsaDesktop?: unknown }).dsaDesktop;
    vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:mock');
    vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => undefined);
    vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(mockedAnchorClick);
    // jsdom does not implement `scrollIntoView` (scrolls would throw); stub it up front
    // for every test, and let the scroll assertions read this shared stub.
    HTMLElement.prototype.scrollIntoView = vi.fn();
    resetSharedDesktopUpdateState();
  });

  afterEach(() => {
    resetSharedDesktopUpdateState();
  });

  it('renders category navigation and auth settings modules', async () => {
    renderSettingsPage();

    expect(await screen.findByRole('heading', { name: '系统设置' })).toBeInTheDocument();
    expect(screen.getByText('认证与登录保护')).toBeInTheDocument();
    expect(screen.getByText('修改密码')).toBeInTheDocument();
    expect(load).toHaveBeenCalled();
  });

  it('renders first-run setup checks and routes setup actions', async () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));

    renderSettingsPage();

    expect(await screen.findByTestId('first-run-setup-card')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: '首次启动配置检查' })).toBeInTheDocument();
    expect(screen.getByText('自选股')).toBeInTheDocument();
    expect(screen.getAllByText('已配置')).toHaveLength(2);

    fireEvent.click(screen.getByRole('button', { name: '配置模型' }));
    fireEvent.click(screen.getByRole('button', { name: '维护自选股' }));
    fireEvent.click(screen.getByRole('button', { name: '配置通知' }));

    expect(setActiveCategory).toHaveBeenNthCalledWith(1, 'ai_model');
    expect(setActiveCategory).toHaveBeenNthCalledWith(2, 'base');
    expect(setActiveCategory).toHaveBeenNthCalledWith(3, 'notification');
  });

  it('scrolls to and focuses the stock list field when the setup guide watchlist action is used', async () => {
    const scrollIntoView = HTMLElement.prototype.scrollIntoView;
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));

    renderSettingsPage();

    expect(await screen.findByTestId('first-run-setup-card')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '维护自选股' }));

    expect(scrollIntoView).toHaveBeenCalled();
    expect(document.activeElement).toBe(document.getElementById('setting-STOCK_LIST'));
  });

  it('applies category from the search string and scrolls to desktop version info', async () => {
    const scrollIntoView = HTMLElement.prototype.scrollIntoView;
    (window as { dsaDesktop?: unknown }).dsaDesktop = {
      version: '3.12.0',
      getUpdateState: desktopGetUpdateState,
      checkForUpdates: desktopCheckForUpdates,
      installDownloadedUpdate: desktopInstallDownloadedUpdate,
      openReleasePage: desktopOpenReleasePage,
      onUpdateStateChange: desktopOnUpdateStateChange,
    };

    renderSettingsPage(['/settings?category=system#desktop-version-info']);

    await waitFor(() => expect(setActiveCategory).toHaveBeenCalledWith('system'));
    expect(await screen.findByText('桌面端更新')).toBeInTheDocument();
    await waitFor(() => expect(scrollIntoView).toHaveBeenCalled());
  });

  it('keeps first-run setup summary neutral while setup status is loading', async () => {
    getSetupStatus.mockImplementation(() => new Promise(() => undefined));
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));

    renderSettingsPage();

    expect(await screen.findByText('正在检查首次启动配置')).toBeInTheDocument();
    expect(screen.getByText('正在读取配置状态，完成后会显示缺失项和试跑入口。')).toBeInTheDocument();
    expect(screen.queryByText('基础配置已满足最小可用分析')).not.toBeInTheDocument();
    expect(screen.queryByText('还有基础配置需要处理')).not.toBeInTheDocument();
    expect(screen.queryByText('所有必需项已就绪，可运行一次简短分析验证链路。')).not.toBeInTheDocument();
  });

  it('keeps first-run setup summary neutral when setup status fails', async () => {
    getSetupStatus.mockRejectedValue(new Error('setup status unavailable'));
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));

    renderSettingsPage();

    expect(await screen.findByText('暂无法判断配置状态')).toBeInTheDocument();
    expect(screen.getByText('配置状态读取失败。可先检查或修改设置项，稍后刷新检查结果。')).toBeInTheDocument();
    expect(screen.queryByText('基础配置已满足最小可用分析')).not.toBeInTheDocument();
    expect(screen.queryByText('还有基础配置需要处理')).not.toBeInTheDocument();
    expect(screen.queryByText('所有必需项已就绪，可运行一次简短分析验证链路。')).not.toBeInTheDocument();
  });

  it('keeps the latest first-run setup status when refresh responses resolve out of order', async () => {
    const staleRefresh = createDeferred<SetupStatusResponse>();
    const latestRefresh = createDeferred<SetupStatusResponse>();
    const initialStatus: SetupStatusResponse = {
      isComplete: true,
      readyForSmoke: true,
      requiredMissingKeys: [],
      nextStepKey: null,
      checks: [
        {
          key: 'initial-status',
          title: '初始状态',
          category: 'base',
          required: true,
          status: 'configured',
          message: '初始配置状态。',
          nextStep: null,
        },
      ],
    };
    const staleStatus: SetupStatusResponse = {
      isComplete: false,
      readyForSmoke: false,
      requiredMissingKeys: ['LLM_CHANNELS'],
      nextStepKey: 'LLM_CHANNELS',
      checks: [
        {
          key: 'stale-status',
          title: '过期状态',
          category: 'ai_model',
          required: true,
          status: 'needs_action',
          message: '过期的配置状态。',
          nextStep: '这条旧响应不应覆盖最新状态。',
        },
      ],
    };
    const latestStatus: SetupStatusResponse = {
      isComplete: true,
      readyForSmoke: true,
      requiredMissingKeys: [],
      nextStepKey: null,
      checks: [
        {
          key: 'latest-status',
          title: '最新状态',
          category: 'base',
          required: true,
          status: 'configured',
          message: '最新配置状态。',
          nextStep: null,
        },
      ],
    };

    getSetupStatus
      .mockResolvedValueOnce(initialStatus)
      .mockImplementationOnce(() => staleRefresh.promise)
      .mockImplementationOnce(() => latestRefresh.promise);
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));

    renderSettingsPage();

    expect(await screen.findByText('初始状态')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '刷新检查' }));
    fireEvent.click(screen.getByRole('button', { name: 'merge stock list' }));

    await waitFor(() => expect(getSetupStatus).toHaveBeenCalledTimes(3));

    await act(async () => {
      latestRefresh.resolve(latestStatus);
      await latestRefresh.promise;
    });

    expect(await screen.findByText('最新状态')).toBeInTheDocument();
    expect(screen.queryByText('过期状态')).not.toBeInTheDocument();

    await act(async () => {
      staleRefresh.resolve(staleStatus);
      await staleRefresh.promise;
    });

    await waitFor(() => expect(screen.getByText('最新状态')).toBeInTheDocument());
    expect(screen.queryByText('过期状态')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '简短试跑' })).toBeEnabled();
  });

  it('runs a brief setup smoke analysis with the first watchlist stock', async () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));

    renderSettingsPage();

    await screen.findByText('基础配置已满足最小可用分析');
    fireEvent.click(screen.getByRole('button', { name: '简短试跑' }));

    await waitFor(() => expect(analyzeAsync).toHaveBeenCalledWith({
      stockCode: 'SH600000',
      reportType: 'brief',
      asyncMode: true,
      notify: false,
      originalQuery: 'SH600000',
      selectionSource: 'manual',
    }));
    expect(await screen.findByText(/task-setup-smoke/)).toBeInTheDocument();
  });

  it('allows brief setup smoke when only the Agent channel is incomplete', async () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));
    getSetupStatus.mockResolvedValue({
      isComplete: false,
      readyForSmoke: true,
      requiredMissingKeys: ['llm_agent'],
      nextStepKey: 'llm_agent',
      checks: [
        {
          key: 'llm_primary',
          title: 'LLM 主渠道',
          category: 'ai_model',
          required: true,
          status: 'configured',
          message: '已启用 Claude Code CLI 本地生成 Backend（experimental/limited）。',
          nextStep: null,
        },
        {
          key: 'llm_agent',
          title: 'Agent 渠道',
          category: 'agent',
          required: true,
          status: 'needs_action',
          message: 'Agent 工具调用需要 LiteLLM 模型配置；local CLI 主生成方式不会被自动继承。',
          nextStep: '如需使用 Ask-Stock Agent，请配置 LiteLLM 模型。',
        },
        {
          key: 'stock_list',
          title: '自选股',
          category: 'base',
          required: true,
          status: 'configured',
          message: '已配置 1 只股票。',
          nextStep: null,
        },
      ],
    });

    renderSettingsPage();

    await screen.findByText('还缺少 1 项：Agent 渠道');
    expect(screen.getByRole('button', { name: '简短试跑' })).toBeEnabled();

    fireEvent.click(screen.getByRole('button', { name: '简短试跑' }));

    await waitFor(() => expect(analyzeAsync).toHaveBeenCalledWith({
      stockCode: 'SH600000',
      reportType: 'brief',
      asyncMode: true,
      notify: false,
      originalQuery: 'SH600000',
      selectionSource: 'manual',
    }));
  });

  it('shows missing setup items and lets the user reopen the setup check', async () => {
    getSetupStatus.mockResolvedValue({
      isComplete: false,
      readyForSmoke: false,
      requiredMissingKeys: ['LLM_CHANNELS'],
      nextStepKey: 'LLM_CHANNELS',
      checks: [
        {
          key: 'llm_channels',
          title: '模型渠道',
          category: 'ai_model',
          required: true,
          status: 'needs_action',
          message: '还没有配置模型渠道。',
          nextStep: '请先配置模型渠道。',
        },
      ],
    });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));

    renderSettingsPage();

    expect(await screen.findByText('还有基础配置需要处理')).toBeInTheDocument();
    expect(screen.getByText('还缺少 1 项：模型渠道')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '简短试跑' })).toBeDisabled();

    fireEvent.click(screen.getByRole('button', { name: '暂时隐藏' }));
    expect(screen.getByText('首次启动配置检查已隐藏')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '展开检查' }));
    expect(screen.getByText('首次启动配置检查')).toBeInTheDocument();
  });

  it('renders web build info in system settings', async () => {
    renderSettingsPage();

    expect(await screen.findByRole('heading', { name: '版本信息' })).toBeInTheDocument();
    expect(screen.getByText('3.11.0')).toBeInTheDocument();
    expect(screen.getByText('abc123def456')).toBeInTheDocument();
    expect(screen.getByText('2026-03-29T02:15:30.000Z')).toBeInTheDocument();
  });

  it('renders desktop app version in system settings during desktop runtime', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = { version: '3.12.0' };

    renderSettingsPage();

    expect(await screen.findByRole('heading', { name: '版本信息' })).toBeInTheDocument();
    expect(screen.getByText('桌面端版本')).toBeInTheDocument();
    expect(screen.getByText('3.12.0')).toBeInTheDocument();
  });

  it('keeps version grid at three columns when desktop runtime has no usable version', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = { version: '   ' };

    renderSettingsPage();

    const section = (await screen.findByRole('heading', { name: '版本信息' })).closest('section');
    const versionGrid = section?.querySelector('div.grid.grid-cols-1.gap-3');

    expect(screen.queryByText('桌面端版本')).not.toBeInTheDocument();
    expect(versionGrid).toHaveClass('md:grid-cols-3');
    expect(versionGrid).not.toHaveClass('md:grid-cols-4');
  });

  it('ignores non-string desktop runtime version values without breaking render', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = { version: 3120 };

    renderSettingsPage();

    const section = (await screen.findByRole('heading', { name: '版本信息' })).closest('section');
    const versionGrid = section?.querySelector('div.grid.grid-cols-1.gap-3');

    expect(screen.queryByText('桌面端版本')).not.toBeInTheDocument();
    expect(versionGrid).toHaveClass('md:grid-cols-3');
  });

  it('normalizes malformed desktop update payloads instead of throwing', async () => {
    desktopGetUpdateState.mockResolvedValue({
      status: 123,
      currentVersion: 3120,
      latestVersion: null,
      releaseUrl: { href: 'https://example.com' },
      checkedAt: ['2026-04-25T01:02:00Z'],
      message: false,
      releaseName: { text: 'v3.13.0' },
      tagName: undefined,
    });
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    renderSettingsPage();

    await waitFor(() => {
      expect(desktopGetUpdateState).toHaveBeenCalledTimes(1);
    });
    expect(screen.getByRole('button', { name: '检查更新' })).toBeInTheDocument();
    expect(screen.queryByText('检查更新失败')).not.toBeInTheDocument();
    expect(screen.queryByText('发现新版本')).not.toBeInTheDocument();
  });

  it('uses an explicit development label instead of presenting a build ID as the version', () => {
    expect(resolveWebBuildInfo({
      packageVersion: '0.0.0',
      revision: 'abc123def456',
      buildTimestamp: '2026-03-29T02:15:30.000Z',
    })).toEqual({
      version: 'development',
      rawVersion: '0.0.0',
      revision: 'abc123def456',
      buildId: 'build-20260329-021530Z',
      buildTime: '2026-03-29T02:15:30.000Z',
      isFallbackVersion: true,
    });
  });

  it('renders fallback version hint when package version is placeholder', async () => {
    Object.assign(webBuildInfoMock, {
      version: 'development',
      rawVersion: '0.0.0',
      revision: 'abc123def456',
      buildId: 'build-20260329-021530Z',
      buildTime: '2026-03-29T02:15:30.000Z',
      isFallbackVersion: true,
    });

    renderSettingsPage();

    expect(await screen.findByRole('heading', { name: '版本信息' })).toBeInTheDocument();
    expect(screen.getByText(/当前构建未提供发布版本/)).toBeInTheDocument();
    expect(screen.getByText('development')).toBeInTheDocument();
    expect(screen.getByText('abc123def456')).toBeInTheDocument();
  });

  it('resets local drafts from the page header button', () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 2 }));

    renderSettingsPage();

    // Clear the initial load call from useEffect
    vi.clearAllMocks();

    fireEvent.click(screen.getByRole('button', { name: '重置' }));

    // Reset should call resetDraft and NOT call load
    expect(resetDraft).toHaveBeenCalledTimes(1);
    expect(load).not.toHaveBeenCalled();
  });

  it('shows deep research and event monitor fields in the agent category when available', () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'agent',
      itemsByCategory: {
        ...buildSystemConfigState().itemsByCategory,
        agent: [
          {
            key: 'AGENT_ORCHESTRATOR_TIMEOUT_S',
            value: '600',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'AGENT_ORCHESTRATOR_TIMEOUT_S',
              category: 'agent',
              dataType: 'integer',
              uiControl: 'number',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 1,
            },
          },
          {
            key: 'AGENT_DEEP_RESEARCH_BUDGET',
            value: '30000',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'AGENT_DEEP_RESEARCH_BUDGET',
              category: 'agent',
              dataType: 'integer',
              uiControl: 'number',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 2,
            },
          },
          {
            key: 'AGENT_EVENT_MONITOR_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'AGENT_EVENT_MONITOR_ENABLED',
              category: 'agent',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 3,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    expect(screen.getByText('AGENT_ORCHESTRATOR_TIMEOUT_S')).toBeInTheDocument();
    expect(screen.getByText('AGENT_DEEP_RESEARCH_BUDGET')).toBeInTheDocument();
    expect(screen.getByText('AGENT_EVENT_MONITOR_ENABLED')).toBeInTheDocument();
    expect(settingsPanelErrorBoundary).toHaveBeenCalledWith('Agent 设置');
  });

  it('keeps retired settings visible for correction without an architecture workaround', () => {
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'agent',
      hasDirty: true,
      dirtyCount: 2,
      getChangedItems: () => [
        { key: 'AGENT_BACKEND', value: 'codex_app_server' },
        { key: 'AGENT_ARCH', value: 'multi' },
      ],
      itemsByCategory: {
        ...configState.itemsByCategory,
        agent: [
          buildAgentItem('AGENT_BACKEND', 'codex_app_server', 1, 'select'),
          buildAgentItem('AGENT_GENERATION_BACKEND', 'auto', 2, 'select'),
          buildAgentItem('AGENT_LITELLM_MODEL', 'openai/gpt-4o-mini', 3),
          buildAgentItem('AGENT_MAX_STEPS', '10', 4, 'number'),
          buildAgentItem('AGENT_ARCH', 'multi', 5, 'select'),
          buildAgentItem('AGENT_ORCHESTRATOR_TIMEOUT_S', '600', 6, 'number'),
        ],
      },
    }));

    renderSettingsPage();

    expect(screen.getByTestId('settings-field-AGENT_BACKEND')).toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-AGENT_GENERATION_BACKEND')).not.toBeInTheDocument();
    expect(screen.getByTestId('settings-field-AGENT_MAX_STEPS')).toHaveAttribute('data-disabled', 'false');
    expect(screen.getByTestId('settings-field-AGENT_ARCH')).toHaveAttribute(
      'data-issues',
      '',
    );
    expect(screen.getByTestId('agent-backend-status-items')).toHaveTextContent(
      'AGENT_BACKEND=codex_app_server|AGENT_ARCH=multi',
    );

    expect(screen.queryByRole('button', { name: '切换为单 Agent' })).not.toBeInTheDocument();
    expect(save).not.toHaveBeenCalled();
  });

  it('renders context compression profile labels and blank preset guidance in agent settings', () => {
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'agent',
      itemsByCategory: {
        ...configState.itemsByCategory,
        agent: [
          {
            key: 'AGENT_CONTEXT_COMPRESSION_PROFILE',
            value: 'balanced',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'AGENT_CONTEXT_COMPRESSION_PROFILE',
              category: 'agent',
              dataType: 'string',
              uiControl: 'select',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [
                { label: '成本优先', value: 'cost' },
                { label: '均衡推荐', value: 'balanced' },
                { label: '长上下文原文优先', value: 'long_context_raw_first' },
              ],
              validation: {
                enum: ['cost', 'balanced', 'long_context_raw_first'],
              },
              displayOrder: 72,
            },
          },
          {
            key: 'AGENT_CONTEXT_COMPRESSION_TRIGGER_TOKENS',
            value: '',
            rawValueExists: false,
            isMasked: false,
            schema: {
              key: 'AGENT_CONTEXT_COMPRESSION_TRIGGER_TOKENS',
              category: 'agent',
              dataType: 'integer',
              uiControl: 'number',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: { min: 1000 },
              displayOrder: 73,
              description: '估算历史 token 超过该值时触发摘要；留空则跟随当前上下文压缩策略 profile 默认值。',
            },
          },
          {
            key: 'AGENT_CONTEXT_PROTECTED_TURNS',
            value: '',
            rawValueExists: false,
            isMasked: false,
            schema: {
              key: 'AGENT_CONTEXT_PROTECTED_TURNS',
              category: 'agent',
              dataType: 'integer',
              uiControl: 'number',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: { min: 1 },
              displayOrder: 74,
              description: '压缩时最近 N 个用户轮次及其后的回复保持原文；留空则跟随当前上下文压缩策略 profile 默认值。',
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    expect(screen.getByText('AGENT_CONTEXT_COMPRESSION_PROFILE')).toBeInTheDocument();
    expect(screen.getByText('成本优先')).toBeInTheDocument();
    expect(screen.getByText('均衡推荐')).toBeInTheDocument();
    expect(screen.getByText('长上下文原文优先')).toBeInTheDocument();
    expect(screen.getByText(/估算历史 token 超过该值时触发摘要/)).toHaveTextContent('留空则跟随当前上下文压缩策略 profile 默认值');
    expect(screen.getByText(/压缩时最近 N 个用户轮次及其后的回复保持原文/)).toHaveTextContent('留空则跟随当前上下文压缩策略 profile 默认值');
  });

  it('reset button semantic: discards local changes without network request', () => {
    // Simulate user has unsaved drafts
    const dirtyState = buildSystemConfigState({
      hasDirty: true,
      dirtyCount: 2,
    });

    useSystemConfigMock.mockReturnValue(dirtyState);

    renderSettingsPage();

    // Clear initial useEffect load call
    vi.clearAllMocks();

    // Click reset button
    fireEvent.click(screen.getByRole('button', { name: '重置' }));

    // Verify semantic: reset should only discard local changes
    // It should NOT trigger a network load
    expect(resetDraft).toHaveBeenCalledTimes(1);
    expect(load).not.toHaveBeenCalled();
    expect(save).not.toHaveBeenCalled();
  });

  it('refreshes server state after intelligent import merges stock list', async () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base' }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: 'merge stock list' }));

    expect(refreshAfterExternalSave).toHaveBeenCalledWith(['STOCK_LIST']);
    expect(load).toHaveBeenCalledTimes(1);
  });

  it('refreshes server state after llm channel editor saves', async () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'ai_model' }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: 'save llm channels' }));

    expect(refreshAfterExternalSave).toHaveBeenCalledWith(['LLM_CHANNELS']);
    expect(load).toHaveBeenCalledTimes(1);
  });

  it('passes merged generation backend draft items to the backend status panel', async () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'ai_model',
      getChangedItems: () => [
        { key: 'GENERATION_BACKEND', value: 'litellm' },
        { key: 'LLM_CHANNELS', value: 'saved' },
        { key: 'OPENAI_MODEL', value: 'gpt-draft' },
        { key: 'GEMINI_MODEL', value: 'gemini-draft' },
        { key: 'OLLAMA_API_BASE', value: 'http://localhost:11434' },
        { key: 'WECHAT_WEBHOOK_URL', value: 'not-a-url' },
      ],
    }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: 'emit llm draft' }));

    const statusItems = await screen.findByTestId('generation-backend-status-items');
    await waitFor(() => {
      expect(statusItems).toHaveTextContent('GENERATION_BACKEND=litellm');
      expect(statusItems).toHaveTextContent('LLM_CHANNELS=draft,backup');
      expect(statusItems).toHaveTextContent('LLM_DRAFT_API_SURFACE=responses');
      expect(statusItems).toHaveTextContent('LITELLM_MODEL=openai/draft-model');
      expect(statusItems).toHaveTextContent('OPENAI_MODEL=gpt-draft');
      expect(statusItems).toHaveTextContent('GEMINI_MODEL=gemini-draft');
      expect(statusItems).toHaveTextContent('OLLAMA_API_BASE=http://localhost:11434');
      expect(statusItems).not.toHaveTextContent('GENERATION_BACKEND=codex_cli');
      expect(statusItems).not.toHaveTextContent('WECHAT_WEBHOOK_URL=not-a-url');
    });
  });

  it('clears llm channel draft items after llm channel editor saves', async () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'ai_model' }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: 'emit llm draft' }));
    expect(await screen.findByTestId('generation-backend-status-items')).toHaveTextContent('LLM_CHANNELS=draft,backup');

    fireEvent.click(screen.getByRole('button', { name: 'save llm channels' }));

    await waitFor(() => {
      expect(screen.getByTestId('generation-backend-status-items')).not.toHaveTextContent('LLM_CHANNELS=draft,backup');
    });
    expect(refreshAfterExternalSave).toHaveBeenCalledWith(['LLM_CHANNELS']);
  });

  it('keeps prompt cache settings collapsed and expandable at the bottom of AI model settings', () => {
    const aiField = (key: string, displayOrder: number, value = '') => ({
      key,
      value,
      rawValueExists: Boolean(value),
      isMasked: false,
      schema: {
        key,
        category: 'ai_model',
        dataType: 'string',
        uiControl: key === 'LLM_PROMPT_CACHE_DIAGNOSTICS_LEVEL' ? 'select' : 'text',
        isSensitive: false,
        isRequired: false,
        isEditable: true,
        options: key === 'LLM_PROMPT_CACHE_DIAGNOSTICS_LEVEL' ? ['off', 'basic', 'debug'] : [],
        validation: {},
        displayOrder,
      },
    });
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'ai_model',
      itemsByCategory: {
        ...configState.itemsByCategory,
        ai_model: [
          aiField('LITELLM_CONFIG', 10, './litellm.yaml'),
          aiField('LLM_PROMPT_CACHE_TELEMETRY_ENABLED', 20, 'true'),
          aiField('LLM_PROMPT_CACHE_HINTS_ENABLED', 21, 'false'),
          aiField('LLM_PROMPT_CACHE_DIAGNOSTICS_LEVEL', 22, 'off'),
        ],
      },
    }));

    const { container } = renderSettingsPage();

    const promptCacheSummary = screen.getByText('Provider Prompt Cache 高级设置').closest('summary');
    const promptCacheDetails = promptCacheSummary?.closest('details');
    const telemetryField = screen.getByTestId('settings-field-LLM_PROMPT_CACHE_TELEMETRY_ENABLED');
    const hintsField = screen.getByTestId('settings-field-LLM_PROMPT_CACHE_HINTS_ENABLED');
    const diagnosticsField = screen.getByTestId('settings-field-LLM_PROMPT_CACHE_DIAGNOSTICS_LEVEL');

    expect(promptCacheSummary).toBeInTheDocument();
    expect(promptCacheDetails).toBeInTheDocument();
    expect(promptCacheDetails).not.toHaveAttribute('open');
    expect(promptCacheDetails).toContainElement(telemetryField);
    expect(promptCacheDetails).toContainElement(hintsField);
    expect(promptCacheDetails).toContainElement(diagnosticsField);
    expect(telemetryField).not.toBeVisible();
    expect(hintsField).not.toBeVisible();
    expect(diagnosticsField).not.toBeVisible();

    fireEvent.click(promptCacheSummary as HTMLElement);

    expect(promptCacheDetails).toHaveAttribute('open');
    expect(telemetryField).toBeVisible();
    expect(hintsField).toBeVisible();
    expect(diagnosticsField).toBeVisible();

    expect(Array.from(container.querySelectorAll('[data-testid^="settings-field-"]')).map((node) => node.getAttribute('data-testid'))).toEqual([
      'settings-field-LITELLM_CONFIG',
      'settings-field-LLM_PROMPT_CACHE_TELEMETRY_ENABLED',
      'settings-field-LLM_PROMPT_CACHE_HINTS_ENABLED',
      'settings-field-LLM_PROMPT_CACHE_DIAGNOSTICS_LEVEL',
    ]);
  });

  it('notifies screening status after generic save when SCREENING_ENABLED is set false', async () => {
    save.mockResolvedValue({ success: true });
    getChangedItems.mockReturnValue([{ key: 'SCREENING_ENABLED', value: 'false' }]);

    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      hasDirty: true,
      dirtyCount: 1,
      getChangedItems: () => [{ key: 'SCREENING_ENABLED', value: 'false' }],
    }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: /保存配置/ }));

    await waitFor(() => expect(save).toHaveBeenCalledTimes(1));
    expect(notifyScreeningConfigChanged).toHaveBeenCalledTimes(1);
    expect(notifySystemConfigChanged).toHaveBeenCalledTimes(1);
    expect(screeningEnable).not.toHaveBeenCalled();
  });

  it('runs the Screening enable flow after generic save when SCREENING_ENABLED is set true', async () => {
    save.mockResolvedValue({ success: true });
    getChangedItems.mockReturnValue([{ key: 'SCREENING_ENABLED', value: 'true' }]);

    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      hasDirty: true,
      dirtyCount: 1,
      getChangedItems: () => [{ key: 'SCREENING_ENABLED', value: 'true' }],
    }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: /保存配置/ }));

    await waitFor(() => expect(save).toHaveBeenCalledTimes(1));
    expect(notifySystemConfigChanged).toHaveBeenCalledTimes(1);
    expect(screeningEnable).toHaveBeenCalledTimes(1);
    expect(refreshAfterExternalSave).toHaveBeenCalledWith(['SCREENING_ENABLED']);
  });

  it('does not notify screening status when generic save updates other fields', async () => {
    save.mockResolvedValue({ success: true });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      hasDirty: true,
      dirtyCount: 1,
      getChangedItems: () => [{ key: 'LLM_CHANNELS', value: 'primary,backup' }],
    }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: /保存配置/ }));

    await waitFor(() => expect(save).toHaveBeenCalledTimes(1));
    expect(notifySystemConfigChanged).toHaveBeenCalledTimes(1);
    expect(notifyScreeningConfigChanged).not.toHaveBeenCalled();
  });

  it('runs Screening enable flow from the settings card', async () => {
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'base',
      itemsByCategory: {
        ...configState.itemsByCategory,
        base: [
          ...configState.itemsByCategory.base,
          {
            key: 'SCREENING_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCREENING_ENABLED',
              category: 'base',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 16,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: '开启选股' }));

    await waitFor(() => expect(screeningEnable).toHaveBeenCalledTimes(1));
    expect(updateSystemConfig).not.toHaveBeenCalled();
    expect(refreshAfterExternalSave).toHaveBeenCalledWith(['SCREENING_ENABLED']);
  });

  it('maps SCREENING_ENABLED to the built-in screening card instead of a generic field', () => {
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'base',
      itemsByCategory: {
        ...configState.itemsByCategory,
        base: [
          ...configState.itemsByCategory.base,
          {
            key: 'SCREENING_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCREENING_ENABLED',
              category: 'base',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 16,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    expect(screen.getByRole('button', { name: '开启选股' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '查看配置项' })).not.toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-SCREENING_ENABLED')).not.toBeInTheDocument();
  });

  it('shows the Screening control only on the base settings page', async () => {
    const configState = buildSystemConfigState();
    const baseItems = [
      ...configState.itemsByCategory.base,
      {
        key: 'SCREENING_ENABLED',
        value: 'false',
        rawValueExists: true,
        isMasked: false,
        schema: {
          key: 'SCREENING_ENABLED',
          category: 'base',
          dataType: 'boolean',
          uiControl: 'switch',
          isSensitive: false,
          isRequired: false,
          isEditable: true,
          options: [],
          validation: {},
          displayOrder: 16,
        },
      },
    ];

    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'base',
      itemsByCategory: {
        ...configState.itemsByCategory,
        base: baseItems,
      },
    }));

    const { rerenderSettingsPage } = renderSettingsPage();
    expect(await screen.findByRole('heading', { name: '首次启动配置检查' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: '选股' })).toBeInTheDocument();

    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'ai_model',
      itemsByCategory: {
        ...configState.itemsByCategory,
        base: baseItems,
      },
    }));
    rerenderSettingsPage();
    expect(screen.queryByRole('heading', { name: '首次启动配置检查' })).not.toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: '选股' })).not.toBeInTheDocument();

    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'data_source',
      itemsByCategory: {
        ...configState.itemsByCategory,
        base: baseItems,
      },
    }));
    rerenderSettingsPage();
    expect(screen.queryByRole('heading', { name: '选股' })).not.toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: '首次启动配置检查' })).not.toBeInTheDocument();
  });

  it('maps schedule settings to the scheduler card instead of generic raw fields', async () => {
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'true',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIME',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIME',
              category: 'system',
              dataType: 'time',
              uiControl: 'time',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 10,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '09:20,15:10',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
          {
            key: 'SCHEDULE_RUN_IMMEDIATELY',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_RUN_IMMEDIATELY',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 12,
            },
          },
          {
            key: 'LOG_LEVEL',
            value: 'INFO',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'LOG_LEVEL',
              category: 'system',
              dataType: 'string',
              uiControl: 'select',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: ['INFO', 'DEBUG'],
              validation: {},
              displayOrder: 50,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    expect(await screen.findByTestId('scheduler-settings-card')).toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-SCHEDULE_ENABLED')).not.toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-SCHEDULE_TIME')).not.toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-SCHEDULE_TIMES')).not.toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-SCHEDULE_RUN_IMMEDIATELY')).not.toBeInTheDocument();
    expect(screen.getByTestId('settings-field-LOG_LEVEL')).toBeInTheDocument();

    fireEvent.change(screen.getByTestId('scheduler-time-input-0'), {
      target: { value: '10:30' },
    });

    expect(setDraftValue).toHaveBeenCalledWith('SCHEDULE_TIMES', '10:30,15:10');

    fireEvent.click(screen.getByTestId('scheduler-run-now-button'));

    await waitFor(() => expect(runSchedulerNow).toHaveBeenCalledTimes(1));
  });

  it('shows an error when run-now is rejected because analysis is already running', async () => {
    runSchedulerNow.mockRejectedValueOnce(new Error('A scheduled analysis is already running'));
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'true',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    fireEvent.click(await screen.findByTestId('scheduler-run-now-button'));

    await waitFor(() => expect(runSchedulerNow).toHaveBeenCalledTimes(1));
    expect(await screen.findByText(/A scheduled analysis is already running/)).toBeInTheDocument();
  });

  it('does not show a failed run as the last successful scheduler run', async () => {
    const configState = buildSystemConfigState();
    getSchedulerStatus.mockResolvedValueOnce({
      enabled: true,
      running: false,
      scheduleTimes: ['18:00'],
      nextRunAt: null,
      lastRunAt: '2026-06-21T17:00:00+08:00',
      lastSuccessAt: null,
      lastError: 'analysis failed',
    });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'true',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    expect(await screen.findByTestId('scheduler-last-success')).toHaveTextContent('-');
    expect(screen.getByTestId('scheduler-last-error')).toHaveTextContent('analysis failed');
  });

  it('shows active runtime scheduler state even when saved schedule flag is false', async () => {
    const configState = buildSystemConfigState();
    getSchedulerStatus.mockResolvedValueOnce({
      enabled: true,
      running: false,
      scheduleTimes: ['18:00'],
      nextRunAt: null,
      lastRunAt: null,
      lastSuccessAt: null,
      lastError: null,
    });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    const enabledCheckbox = await screen.findByTestId('scheduler-enabled-checkbox');
    expect(enabledCheckbox).toBeChecked();

    fireEvent.click(enabledCheckbox);

    expect(setDraftValue).toHaveBeenCalledWith('SCHEDULE_ENABLED', 'false');
    await waitFor(() => expect(enabledCheckbox).not.toBeChecked());
  });

  it('keeps local scheduler toggle edits when runtime and saved states are initially consistent', async () => {
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'true',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));
    renderSettingsPage();

    const enabledCheckbox = await screen.findByTestId('scheduler-enabled-checkbox');
    expect(enabledCheckbox).toBeChecked();

    fireEvent.click(enabledCheckbox);

    expect(setDraftValue).toHaveBeenCalledWith('SCHEDULE_ENABLED', 'false');
    await waitFor(() => expect(screen.getByTestId('scheduler-enabled-checkbox')).not.toBeChecked());

    const refreshButton = screen.getByTestId('scheduler-refresh-status-button');
    fireEvent.click(refreshButton);
    await waitFor(() => expect(screen.getByTestId('scheduler-enabled-checkbox')).not.toBeChecked());
  });

  it('can reconcile runtime scheduler state when runtime is enabled but saved value is disabled', async () => {
    save.mockResolvedValue({ success: true });
    getChangedItems.mockReturnValue([]);
    const configState = buildSystemConfigState();
    getSchedulerStatus.mockResolvedValueOnce({
      enabled: true,
      running: false,
      scheduleTimes: ['18:00'],
      nextRunAt: null,
      lastRunAt: null,
      lastSuccessAt: null,
      lastError: null,
    });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      hasDirty: false,
      dirtyCount: 0,
      getChangedItems: () => [],
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    const saveButton = screen.getByRole('button', { name: /保存配置/ });
    expect(saveButton).toBeDisabled();

    const enabledCheckbox = await screen.findByTestId('scheduler-enabled-checkbox');
    expect(enabledCheckbox).toBeChecked();
    fireEvent.click(enabledCheckbox);

    await waitFor(() => expect(enabledCheckbox).not.toBeChecked());
    await waitFor(() => expect(saveButton).toBeEnabled());
    await waitFor(() => expect(saveButton).toHaveTextContent('保存配置 (1)'));

    fireEvent.click(saveButton);
    await waitFor(() => expect(save).toHaveBeenCalledWith([{ key: 'SCHEDULE_ENABLED', value: 'false' }]));
  });

  it('resets a scheduler-only override and lets navigation proceed', async () => {
    save.mockResolvedValue({ success: true });
    getChangedItems.mockReturnValue([]);
    const configState = buildSystemConfigState();
    getSchedulerStatus.mockResolvedValue({
      enabled: true,
      running: false,
      scheduleTimes: ['18:00'],
      nextRunAt: null,
      lastRunAt: null,
      lastSuccessAt: null,
      lastError: null,
    });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      hasDirty: false,
      dirtyCount: 0,
      getChangedItems: () => [],
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));

    const { router, rerenderSettingsPage } = renderSettingsPage();

    const saveButton = screen.getByRole('button', { name: /保存配置/ });
    expect(saveButton).toBeDisabled();

    const enabledCheckbox = await screen.findByTestId('scheduler-enabled-checkbox');
    expect(enabledCheckbox).toBeChecked();
    fireEvent.click(enabledCheckbox);

    await waitFor(() => expect(enabledCheckbox).not.toBeChecked());
    await waitFor(() => expect(saveButton).toBeEnabled());
    await waitFor(() => expect(saveButton).toHaveTextContent('保存配置 (1)'));
    const schedulerState = useSystemConfigMock.mock.results.at(-1)?.value;
    useSystemConfigMock.mockReturnValue({ ...schedulerState, activeCategory: 'base' });
    rerenderSettingsPage();
    expect(screen.getByTestId('scheduler-enabled-checkbox')).not.toBeVisible();
    useSystemConfigMock.mockReturnValue(schedulerState);
    rerenderSettingsPage();
    expect(screen.getByTestId('scheduler-enabled-checkbox')).not.toBeChecked();


    act(() => { void router.navigate('/chat'); });
    fireEvent.click(await screen.findByRole('button', { name: '取消' }));
    fireEvent.click(screen.getByRole('button', { name: '重置' }));
    await waitFor(() => expect(screen.getByTestId('scheduler-enabled-checkbox')).toBeChecked());
    expect(saveButton).toBeDisabled();
    act(() => { void router.navigate('/chat'); });
    await waitFor(() => expect(router.state.location.pathname).toBe('/chat'));
  });

  it('can reconcile runtime scheduler state when runtime is disabled but saved value is enabled', async () => {
    save.mockResolvedValue({ success: true });
    getChangedItems.mockReturnValue([]);
    const configState = buildSystemConfigState();
    getSchedulerStatus.mockResolvedValueOnce({
      enabled: false,
      running: false,
      scheduleTimes: ['18:00'],
      nextRunAt: null,
      lastRunAt: null,
      lastSuccessAt: null,
      lastError: null,
    });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      hasDirty: false,
      dirtyCount: 0,
      getChangedItems: () => [],
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'true',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    const saveButton = screen.getByRole('button', { name: /保存配置/ });
    expect(saveButton).toBeDisabled();

    const enabledCheckbox = await screen.findByTestId('scheduler-enabled-checkbox');
    expect(enabledCheckbox).not.toBeChecked();
    fireEvent.click(enabledCheckbox);

    await waitFor(() => expect(enabledCheckbox).toBeChecked());
    await waitFor(() => expect(saveButton).toBeEnabled());
    await waitFor(() => expect(saveButton).toHaveTextContent('保存配置 (1)'));

    fireEvent.click(saveButton);
    await waitFor(() => expect(save).toHaveBeenCalledWith([{ key: 'SCHEDULE_ENABLED', value: 'true' }]));
  });

  it('refreshes scheduler status after saving scheduler settings', async () => {
    const configState = buildSystemConfigState();
    getSchedulerStatus
      .mockResolvedValueOnce({
        enabled: false,
        running: false,
        scheduleTimes: [],
        nextRunAt: null,
        lastRunAt: null,
        lastSuccessAt: null,
        lastError: null,
      })
      .mockResolvedValueOnce({
        enabled: true,
        running: false,
        scheduleTimes: ['09:20', '15:10'],
        nextRunAt: '2026-06-21T09:20:00+08:00',
        lastRunAt: null,
        lastSuccessAt: null,
        lastError: null,
      });
    save.mockResolvedValue({ success: true });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      hasDirty: true,
      dirtyCount: 1,
      getChangedItems: () => [{ key: 'SCHEDULE_ENABLED', value: 'true' }],
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '09:20,15:10',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    expect(await screen.findByText('未启用')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '保存配置 (1)' }));

    await waitFor(() => expect(getSchedulerStatus).toHaveBeenCalledTimes(2));
    expect(await screen.findByText('已启用')).toBeInTheDocument();
  });

  it('refreshes Screening state when the enable flow fails', async () => {
    const configState = buildSystemConfigState();
    screeningEnable.mockRejectedValueOnce(new Error('config update failed'));
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'base',
      itemsByCategory: {
        ...configState.itemsByCategory,
        base: [
          ...configState.itemsByCategory.base,
          {
            key: 'SCREENING_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCREENING_ENABLED',
              category: 'base',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 16,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    fireEvent.click(screen.getByRole('button', { name: '开启选股' }));

    await waitFor(() => expect(screeningEnable).toHaveBeenCalledTimes(1));
    expect(updateSystemConfig).not.toHaveBeenCalled();
    expect(refreshAfterExternalSave).toHaveBeenCalledWith(['SCREENING_ENABLED']);
  });

  it('passes LLM channel support keys to the channel editor without rendering them as generic fields', async () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'ai_model',
      itemsByCategory: {
        ...buildSystemConfigState().itemsByCategory,
        ai_model: [
          {
            key: 'LLM_CHANNELS',
            value: 'my_proxy',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'LLM_CHANNELS',
              category: 'ai_model',
              dataType: 'string',
              uiControl: 'textarea',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 1,
            },
          },
          {
            key: 'LITELLM_MODEL',
            value: 'gpt-5.0',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'LITELLM_MODEL',
              category: 'ai_model',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 2,
            },
          },
          {
            key: 'OPENAI_BASE_URL',
            value: 'https://api.openai.com/v1',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'OPENAI_BASE_URL',
              category: 'ai_model',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 3,
            },
          },
          {
            key: 'OPENAI_MODEL',
            value: 'gpt-5.0',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'OPENAI_MODEL',
              category: 'ai_model',
              isMasked: false,
              dataType: 'string',
              uiControl: 'text',
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 4,
            },
          },
          {
            key: 'LLM_MY_PROXY_API_KEY',
            value: 'sk-test',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'LLM_MY_PROXY_API_KEY',
              category: 'ai_model',
              dataType: 'string',
              uiControl: 'password',
              isSensitive: true,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 9000,
            },
          },
          {
            key: 'LLM_MY_PROXY_MODELS',
            value: 'gpt-5.5',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'LLM_MY_PROXY_MODELS',
              category: 'ai_model',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 9000,
            },
          },
        ],
      },
    }));

    renderSettingsPage();

    const llmEditorItems = await screen.findByTestId('llm-channel-editor-items');
    expect(llmEditorItems).toHaveTextContent('LLM_CHANNELS');
    expect(llmEditorItems).toHaveTextContent('LITELLM_MODEL');
    expect(llmEditorItems).toHaveTextContent('OPENAI_BASE_URL');
    expect(llmEditorItems).toHaveTextContent('OPENAI_MODEL');
    expect(llmEditorItems).toHaveTextContent('LLM_MY_PROXY_API_KEY');
    expect(llmEditorItems).toHaveTextContent('LLM_MY_PROXY_MODELS');
    expect(screen.queryByTestId('settings-field-LITELLM_MODEL')).not.toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-OPENAI_BASE_URL')).not.toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-OPENAI_MODEL')).not.toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-LLM_MY_PROXY_API_KEY')).not.toBeInTheDocument();
    expect(screen.queryByTestId('settings-field-LLM_MY_PROXY_MODELS')).not.toBeInTheDocument();
  });

  it('renders notification test panel before notification fields', () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'notification' }));

    renderSettingsPage();

    expect(screen.getByText('通知测试面板:WECHAT_WEBHOOK_URL')).toBeInTheDocument();
    expect(screen.getByText('WECHAT_WEBHOOK_URL')).toBeInTheDocument();
    expect(settingsPanelErrorBoundary).toHaveBeenCalledWith('通知测试');
    expect(settingsPanelErrorBoundary).toHaveBeenCalledWith('通知设置');
  });

  it('uses browser and backend logs in settings panel diagnostic hints outside desktop runtime', () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'notification' }));

    renderSettingsPage();

    expect(screen.getAllByText(/浏览器开发者工具控制台与后端日志/)).toHaveLength(2);
    expect(screen.queryByText('desktop.log')).not.toBeInTheDocument();
  });

  it('uses desktop log in settings panel diagnostic hints during desktop runtime', () => {
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'notification' }));
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    renderSettingsPage();

    expect(screen.getAllByText('desktop.log')).toHaveLength(2);
    expect(screen.queryByText(/浏览器开发者工具控制台与后端日志/)).not.toBeInTheDocument();
  });

  it('renders env backup actions outside desktop runtime', () => {
    renderSettingsPage();

    expect(screen.getByRole('heading', { name: '配置备份' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '导出 .env' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '导入 .env' })).toBeInTheDocument();
    expect(screen.getByText(/Docker 部署中/)).toHaveTextContent('ENV_FILE');
  });

  it('disables env backup actions when web auth is not enabled', () => {
    useAuthMock.mockReturnValue({
      authEnabled: false,
      passwordChangeable: false,
      refreshStatus,
    });

    renderSettingsPage();

    expect(screen.getByText(/当前 Web 端未开启管理员鉴权/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '导出 .env' })).toBeDisabled();
    expect(screen.getByRole('button', { name: '导入 .env' })).toBeDisabled();
  });

  it('uses live auth state for env backup availability instead of loaded config items', () => {
    const configState = buildSystemConfigState();
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: configState.itemsByCategory.system.map((item) => (
          item.key === 'ADMIN_AUTH_ENABLED' ? { ...item, value: 'false' } : item
        )),
      },
    }));
    useAuthMock.mockReturnValue({
      authEnabled: true,
      passwordChangeable: true,
      refreshStatus,
    });

    renderSettingsPage();

    expect(screen.queryByText(/当前 Web 端未开启管理员鉴权/)).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '导出 .env' })).not.toBeDisabled();
    expect(screen.getByRole('button', { name: '导入 .env' })).not.toBeDisabled();
  });

  it('exports saved env from config backup actions', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = { version: '3.12.0' };

    renderSettingsPage();

    vi.clearAllMocks();

    fireEvent.click(screen.getByRole('button', { name: '导出 .env' }));

    await waitFor(() => expect(exportEnv).toHaveBeenCalledTimes(1));
    expect(mockedAnchorClick).toHaveBeenCalledTimes(1);
    expect(load).not.toHaveBeenCalled();
  });

  it('asks for confirmation before importing when local drafts exist', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = { version: '3.12.0' };
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 2 }));

    renderSettingsPage();

    vi.clearAllMocks();

    fireEvent.click(screen.getByRole('button', { name: '导入 .env' }));

    expect(await screen.findByText('导入会覆盖当前草稿')).toBeInTheDocument();
    expect(importEnv).not.toHaveBeenCalled();
  });

  it('reloads config after successful env import', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = { version: '3.12.0' };

    const { container } = renderSettingsPage();

    vi.clearAllMocks();

    const input = container.querySelector('input[type="file"]');
    expect(input).not.toBeNull();

    fireEvent.change(input as HTMLInputElement, {
      target: {
        files: [new File(['STOCK_LIST=300750\n'], 'desktop-backup.env', { type: 'text/plain' })],
      },
    });

    await waitFor(() => expect(importEnv).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(load).toHaveBeenCalledTimes(1));
  });

  it('refreshes scheduler status after successful env import updates scheduler settings', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = { version: '3.12.0' };
    const configState = buildSystemConfigState();
    getSchedulerStatus
      .mockResolvedValueOnce({
        enabled: false,
        running: false,
        scheduleTimes: ['18:00'],
        nextRunAt: null,
        lastRunAt: null,
        lastSuccessAt: null,
        lastError: null,
      })
      .mockResolvedValueOnce({
        enabled: true,
        running: false,
        scheduleTimes: ['09:20', '15:10'],
        nextRunAt: '2026-06-21T09:20:00+08:00',
        lastRunAt: null,
        lastSuccessAt: null,
        lastError: null,
      });
    importEnv.mockResolvedValueOnce({
      success: true,
      configVersion: 'v2',
      appliedCount: 2,
      skippedMaskedCount: 0,
      reloadTriggered: true,
      updatedKeys: ['SCHEDULE_ENABLED', 'SCHEDULE_TIMES'],
      warnings: [],
    });
    useSystemConfigMock.mockReturnValue(buildSystemConfigState({
      activeCategory: 'system',
      itemsByCategory: {
        ...configState.itemsByCategory,
        system: [
          ...configState.itemsByCategory.system,
          {
            key: 'SCHEDULE_ENABLED',
            value: 'false',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_ENABLED',
              category: 'system',
              dataType: 'boolean',
              uiControl: 'switch',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 8,
            },
          },
          {
            key: 'SCHEDULE_TIMES',
            value: '18:00',
            rawValueExists: true,
            isMasked: false,
            schema: {
              key: 'SCHEDULE_TIMES',
              category: 'system',
              dataType: 'string',
              uiControl: 'text',
              isSensitive: false,
              isRequired: false,
              isEditable: true,
              options: [],
              validation: {},
              displayOrder: 11,
            },
          },
        ],
      },
    }));

    const { container } = renderSettingsPage();

    await waitFor(() => expect(getSchedulerStatus).toHaveBeenCalledTimes(1));
    expect(await screen.findByText('未启用')).toBeInTheDocument();

    vi.clearAllMocks();

    const input = container.querySelector('input[type="file"]');
    expect(input).not.toBeNull();

    fireEvent.change(input as HTMLInputElement, {
      target: {
        files: [new File(['SCHEDULE_ENABLED=true\nSCHEDULE_TIMES=09:20,15:10\n'], 'desktop-backup.env', { type: 'text/plain' })],
      },
    });

    await waitFor(() => expect(importEnv).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(load).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(getSchedulerStatus).toHaveBeenCalledTimes(1));
    expect(await screen.findByText('已启用')).toBeInTheDocument();
  });

  it('shows an error when env import succeeds but reload fails', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = { version: '3.12.0' };
    load.mockResolvedValue(false);

    const { container } = renderSettingsPage();

    vi.clearAllMocks();
    load.mockResolvedValue(false);

    const input = container.querySelector('input[type="file"]');
    expect(input).not.toBeNull();

    fireEvent.change(input as HTMLInputElement, {
      target: {
        files: [new File(['STOCK_LIST=300750\n'], 'desktop-backup.env', { type: 'text/plain' })],
      },
    });

    await waitFor(() => expect(importEnv).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(load).toHaveBeenCalledTimes(1));
    expect(screen.getByText('配置已导入但刷新失败')).toBeInTheDocument();
    expect(screen.getByText('备份已导入，但重新加载配置失败，请手动重载页面。')).toBeInTheDocument();
    expect(screen.queryByText('已导入 .env 备份并重新加载配置。')).not.toBeInTheDocument();
  });

  it('renders desktop update notice when a newer release is available', async () => {
    desktopGetUpdateState.mockResolvedValue({
      status: 'update-available',
      currentVersion: '3.12.0',
      latestVersion: '3.13.0',
      releaseUrl: 'https://github.com/ZhuLinsen/daily_stock_analysis/releases/tag/v3.13.0',
      message: '发现新版本 3.13.0，可前往 GitHub Releases 下载更新。',
    });
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    renderSettingsPage();

    expect(await screen.findByText(/发现新版本:当前 3\.12\.0，最新 3\.13\.0/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '前往下载' })).toBeInTheDocument();
  });

  it('checks desktop updates on demand and renders the latest-version state', async () => {
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    renderSettingsPage();

    fireEvent.click(await screen.findByRole('button', { name: '检查更新' }));

    await waitFor(() => expect(desktopCheckForUpdates).toHaveBeenCalledTimes(1));
    expect(await screen.findByText('已是最新版本:当前桌面端已是最新版本。')).toBeInTheDocument();
  });

  it('opens GitHub release page from desktop update notice', async () => {
    desktopGetUpdateState.mockResolvedValue({
      status: 'update-available',
      currentVersion: '3.12.0',
      latestVersion: '3.13.0',
      releaseUrl: 'https://github.com/ZhuLinsen/daily_stock_analysis/releases/tag/v3.13.0',
      message: '发现新版本 3.13.0，可前往 GitHub Releases 下载更新。',
    });
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    renderSettingsPage();

    fireEvent.click(await screen.findByRole('button', { name: '前往下载' }));

    await waitFor(() => {
      expect(desktopOpenReleasePage).toHaveBeenCalledWith(
        'https://github.com/ZhuLinsen/daily_stock_analysis/releases/tag/v3.13.0'
      );
    });
  });

  it('renders downloaded desktop update and starts install on demand', async () => {
    desktopGetUpdateState.mockResolvedValue({
      status: 'update-downloaded',
      updateMode: 'auto',
      currentVersion: '3.12.0',
      latestVersion: '3.13.0',
      releaseUrl: 'https://github.com/ZhuLinsen/daily_stock_analysis/releases/tag/v3.13.0',
      message: '新版本 3.13.0 已下载，可重启应用完成安装。',
      downloadPercent: 100,
    });
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    renderSettingsPage();

    expect(await screen.findByText('更新已下载:新版本 3.13.0 已下载，可重启应用完成安装。')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '重启安装' }));

    await waitFor(() => expect(desktopInstallDownloadedUpdate).toHaveBeenCalledTimes(1));
  });

  it('disables the settings check button while the header entry is already checking', async () => {
    const pendingCheck = hangDesktopUpdateCheck();
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    renderDesktopUpdateEntries();

    fireEvent.click(await screen.findByRole('button', { name: '桌面端更新' }));
    fireEvent.click(
      within(screen.getByRole('dialog', { name: '桌面端更新' })).getByRole('button', { name: '检查更新' }),
    );

    await waitFor(() => expect(desktopCheckForUpdates).toHaveBeenCalledTimes(1));

    const settingsCard = await waitFor(() => {
      const card = document.querySelector('#desktop-version-info');
      expect(card).not.toBeNull();
      expect(within(card as HTMLElement).getByRole('button', { name: '检查中...' })).toBeDisabled();
      return card as HTMLElement;
    });
    const settingsButton = within(settingsCard).getByRole('button', { name: '检查中...' });

    fireEvent.click(settingsButton);
    expect(desktopCheckForUpdates).toHaveBeenCalledTimes(1);

    await pendingCheck.finish({
      status: 'up-to-date',
      currentVersion: '3.12.0',
      latestVersion: '3.12.0',
      message: '当前桌面端已是最新版本。',
    });
  });

  it('does not start a second check from the header while settings is already checking', async () => {
    const pendingCheck = hangDesktopUpdateCheck();
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    renderDesktopUpdateEntries();

    const settingsCard = await waitFor(() => {
      const card = document.querySelector('#desktop-version-info');
      expect(card).not.toBeNull();
      return card as HTMLElement;
    });
    fireEvent.click(within(settingsCard).getByRole('button', { name: '检查更新' }));

    await waitFor(() => expect(desktopCheckForUpdates).toHaveBeenCalledTimes(1));
    expect(within(settingsCard).getByRole('button', { name: '检查中...' })).toBeDisabled();

    fireEvent.click(screen.getByRole('button', { name: '桌面端更新' }));
    expect(screen.queryByRole('button', { name: '检查更新' })).not.toBeInTheDocument();
    fireEvent.click(within(settingsCard).getByRole('button', { name: '检查中...' }));
    expect(desktopCheckForUpdates).toHaveBeenCalledTimes(1);

    await pendingCheck.finish({
      status: 'up-to-date',
      currentVersion: '3.12.0',
      latestVersion: '3.12.0',
      message: '当前桌面端已是最新版本。',
    });
  });

  it('keeps both entries busy when a late settings mount receives a stale idle snapshot', async () => {
    const pendingCheck = hangDesktopUpdateCheck();
    (window as { dsaDesktop?: unknown }).dsaDesktop = createDesktopRuntime();

    const { router } = renderDesktopUpdateEntries(true);

    fireEvent.click(await screen.findByRole('button', { name: '桌面端更新' }));
    fireEvent.click(
      within(screen.getByRole('dialog', { name: '桌面端更新' })).getByRole('button', { name: '检查更新' }),
    );
    await waitFor(() => expect(desktopCheckForUpdates).toHaveBeenCalledTimes(1));

    await act(async () => { await router.navigate('/settings'); });

    const settingsCard = await waitFor(() => {
      const card = document.querySelector('#desktop-version-info');
      expect(card).not.toBeNull();
      return card as HTMLElement;
    });
    expect(within(settingsCard).getByRole('button', { name: '检查中...' })).toBeDisabled();
    expect(desktopCheckForUpdates).toHaveBeenCalledTimes(1);

    await pendingCheck.finish({
      status: 'up-to-date',
      currentVersion: '3.12.0',
      latestVersion: '3.12.0',
      message: '当前桌面端已是最新版本。',
    });
  });
  describe('unsaved changes navigation guard (issue #1948 point 4)', () => {
    let beforeUnloadListeners: Array<(event: BeforeUnloadEvent) => void>;

    beforeEach(() => {
      // jsdom does not natively dispatch `beforeunload` events on `reload` /
      // close — we approximate the behaviour by tracking whether the page
      // attached a listener and what it does when invoked with a synthetic
      // BeforeUnloadEvent.
      beforeUnloadListeners = [];
      vi.spyOn(window, 'addEventListener').mockImplementation((type, listener) => {
        if (type === 'beforeunload' && typeof listener === 'function') {
          beforeUnloadListeners.push(listener as (event: BeforeUnloadEvent) => void);
        }
        return undefined;
      });
      vi.spyOn(window, 'removeEventListener').mockImplementation((type, listener) => {
        if (type !== 'beforeunload' || typeof listener !== 'function') {
          return;
        }
        const idx = beforeUnloadListeners.indexOf(listener as (event: BeforeUnloadEvent) => void);
        if (idx >= 0) {
          beforeUnloadListeners.splice(idx, 1);
        }
      });
    });

    afterEach(() => {
      vi.restoreAllMocks();
    });

    it('retains real LLM drafts and both guards across category changes', async () => {
      editorTestMode.real = true;
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'ai_model', hasDirty: false }));
      const page = renderSettingsPage();
      fireEvent.click(await screen.findByRole('button', { name: /primary/i }));
      fireEvent.change(await screen.findByLabelText('渠道名称'), { target: { value: 'UNSAVED_NAME' } });
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'base', hasDirty: false }));
      page.rerenderSettingsPage();
      await waitFor(() => expect(screen.getByLabelText('渠道名称')).not.toBeVisible());
      expect(beforeUnloadListeners.length).toBe(1);
      act(() => { void page.router.navigate('/chat'); });
      fireEvent.click(await screen.findByRole('button', { name: '取消' }));
      expect(page.router.state.location.pathname).toBe('/settings');
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'ai_model', hasDirty: false }));
      page.rerenderSettingsPage();
      expect(await screen.findByLabelText('渠道名称')).toHaveValue('unsaved_name');
      expect(screen.getByLabelText('渠道名称')).toBeVisible();
      fireEvent.click(screen.getByRole('button', { name: '重置' }));
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(0));
      fireEvent.click(await screen.findByRole('button', { name: /primary/i }));
      expect(await screen.findByLabelText('渠道名称')).toHaveValue('primary');
    });

    it('waits for a hidden real LLM save and refresh before allowing reset, import, or departure', async () => {
      editorTestMode.real = true;
      const pendingUpdate = createDeferred<{ warnings: string[] }>();
      const pendingRefresh = createDeferred<void>();
      updateSystemConfig.mockReturnValueOnce(pendingUpdate.promise);
      refreshAfterExternalSave.mockReturnValueOnce(pendingRefresh.promise);
      const configState = buildSystemConfigState({ activeCategory: 'ai_model' });
      useSystemConfigMock.mockReturnValue(configState);
      const page = renderSettingsPage();

      fireEvent.click(await screen.findByRole('button', { name: /primary/i }));
      fireEvent.change(await screen.findByLabelText('Base URL'), { target: { value: 'https://draft.example.com/v1' } });
      fireEvent.click(screen.getByRole('button', { name: '保存 AI 配置' }));
      await waitFor(() => expect(updateSystemConfig).toHaveBeenCalledTimes(1));
      expect(screen.getByRole('button', { name: '重置' })).toBeDisabled();
      fireEvent.click(screen.getByRole('button', { name: '重置' }));
      expect(resetDraft).not.toHaveBeenCalled();

      useSystemConfigMock.mockReturnValue({ ...configState, activeCategory: 'system' });
      page.rerenderSettingsPage();
      expect(screen.getByLabelText('Base URL')).not.toBeVisible();
      expect(screen.getByLabelText('Base URL')).toHaveValue('https://draft.example.com/v1');
      expect(screen.getByRole('button', { name: '导入 .env' })).toBeDisabled();
      fireEvent.click(screen.getByRole('button', { name: '导入 .env' }));
      expect(screen.queryByText('导入会覆盖当前草稿')).not.toBeInTheDocument();
      expect(importEnv).not.toHaveBeenCalled();

      act(() => { void page.router.navigate('/chat'); });
      expect(await screen.findByText('配置正在保存。已发出的保存请求不会被取消，请等待保存完成后再离开。')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: '保存中...' })).toBeDisabled();
      expect(screen.queryByRole('button', { name: '放弃并离开' })).not.toBeInTheDocument();
      fireEvent.click(screen.getByRole('button', { name: '取消' }));
      expect(page.router.state.location.pathname).toBe('/settings');

      await act(async () => pendingUpdate.resolve({ warnings: [] }));
      await waitFor(() => expect(refreshAfterExternalSave).toHaveBeenCalledTimes(1));
      const savedItems = updateSystemConfig.mock.calls[0][0].items as Array<{ key: string; value: string }>;
      useSystemConfigMock.mockReturnValue({
        ...configState,
        activeCategory: 'system',
        itemsByCategory: { ...configState.itemsByCategory, ai_model: savedItems },
      });
      page.rerenderSettingsPage();
      await waitFor(() => expect(screen.getByText('当前没有未保存的改动')).not.toBeVisible());
      expect(screen.getByRole('button', { name: '重置' })).toBeDisabled();
      expect(screen.getByRole('button', { name: '导入 .env' })).toBeDisabled();
      expect(beforeUnloadListeners).toHaveLength(1);
      act(() => { void page.router.navigate('/chat'); });
      expect(await screen.findByRole('button', { name: '保存中...' })).toBeDisabled();

      await act(async () => pendingRefresh.resolve());
      expect(await screen.findByText('配置已保存，可以继续离开此页面。')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: '重置' })).toBeEnabled();
      expect(screen.getByRole('button', { name: '导入 .env' })).toBeEnabled();
      expect(beforeUnloadListeners).toHaveLength(0);
      expect(screen.queryByText('当前没有未保存的改动')).not.toBeInTheDocument();
      fireEvent.click(screen.getByRole('button', { name: '确定' }));
      await waitFor(() => expect(page.router.state.location.pathname).toBe('/chat'));
      expect(updateSystemConfig).toHaveBeenCalledTimes(1);
    });

    it('confirms import for a hidden invalid LLM draft and preserves it on Cancel', async () => {
      editorTestMode.real = true;
      const configState = buildSystemConfigState({ activeCategory: 'ai_model' });
      useSystemConfigMock.mockReturnValue(configState);
      const page = renderSettingsPage();
      fireEvent.click(await screen.findByRole('button', { name: /primary/i }));
      fireEvent.change(await screen.findByLabelText('渠道名称'), { target: { value: '' } });
      await waitFor(() => expect(beforeUnloadListeners).toHaveLength(1));
      expect(screen.getByTestId('generation-backend-status-items')).toBeEmptyDOMElement();

      useSystemConfigMock.mockReturnValue({ ...configState, activeCategory: 'system' });
      page.rerenderSettingsPage();
      expect(screen.getByLabelText('渠道名称')).not.toBeVisible();
      fireEvent.click(screen.getByRole('button', { name: '导入 .env' }));
      expect(await screen.findByText('导入会覆盖当前草稿')).toBeInTheDocument();
      fireEvent.click(screen.getByRole('button', { name: '取消' }));
      expect(importEnv).not.toHaveBeenCalled();
      expect(resetDraft).not.toHaveBeenCalled();
      expect(beforeUnloadListeners).toHaveLength(1);

      useSystemConfigMock.mockReturnValue(configState);
      page.rerenderSettingsPage();
      expect(screen.getByLabelText('渠道名称')).toBeVisible();
      expect(screen.getByLabelText('渠道名称')).toHaveValue('');
    });

    it.each(['reloaded', 'reload-failed', 'import-failed'] as const)(
      'handles confirmed import with hidden model and scheduler drafts: %s', async (outcome) => {
        editorTestMode.real = true;
        const pendingImport = createDeferred<{ updatedKeys: string[] }>();
        importEnv.mockReturnValueOnce(pendingImport.promise);
        getSchedulerStatus.mockResolvedValue({ enabled: true, running: false, scheduleTimes: ['18:00'] });
        const initial = buildSystemConfigState({ activeCategory: 'ai_model' });
        const schedulerTemplate = initial.itemsByCategory.system[0];
        const configState = {
          ...initial,
          itemsByCategory: {
            ...initial.itemsByCategory,
            system: [...initial.itemsByCategory.system, {
              ...schedulerTemplate, key: 'SCHEDULE_ENABLED', value: 'false',
              schema: { ...(schedulerTemplate.schema as Record<string, unknown>), key: 'SCHEDULE_ENABLED' },
            }],
          },
        };
        useSystemConfigMock.mockReturnValue(configState);
        const page = renderSettingsPage();
        fireEvent.click(await screen.findByRole('button', { name: /primary/i }));
        fireEvent.change(await screen.findByLabelText('渠道名称'), { target: { value: '' } });
        useSystemConfigMock.mockReturnValue({ ...configState, activeCategory: 'system' });
        page.rerenderSettingsPage();
        await waitFor(() => expect(screen.getByTestId('scheduler-enabled-checkbox')).toBeChecked());
        fireEvent.click(screen.getByTestId('scheduler-enabled-checkbox'));
        await waitFor(() => expect(screen.getByTestId('scheduler-enabled-checkbox')).not.toBeChecked());
        fireEvent.click(screen.getByRole('button', { name: '导入 .env' }));
        expect(await screen.findByText('导入会覆盖当前草稿')).toBeInTheDocument();
        fireEvent.click(screen.getByRole('button', { name: '继续导入' }));
        const fileInput = page.container.querySelector('input[type="file"]') as HTMLInputElement;
        load.mockResolvedValueOnce(outcome !== 'reload-failed');
        fireEvent.change(fileInput, {
          target: { files: [new File(['STOCK_LIST=300750\n'], 'backup.env', { type: 'text/plain' })] },
        });
        await waitFor(() => expect(importEnv).toHaveBeenCalledTimes(1));
        expect(resetDraft).not.toHaveBeenCalled();
        expect(screen.getByLabelText('渠道名称')).toHaveValue('');
        expect(screen.getByRole('button', { name: '重置' })).toBeDisabled();

        if (outcome === 'import-failed') {
          await act(async () => pendingImport.reject(new Error('import rejected')));
          expect(await screen.findByText('import rejected')).toBeInTheDocument();
          expect(resetDraft).not.toHaveBeenCalled();
          expect(screen.getByTestId('scheduler-enabled-checkbox')).not.toBeChecked();
          expect(beforeUnloadListeners).toHaveLength(1);
        } else {
          await act(async () => pendingImport.resolve({ updatedKeys: ['STOCK_LIST'] }));
          await waitFor(() => expect(resetDraft).toHaveBeenCalledTimes(1));
          await waitFor(() => expect(beforeUnloadListeners).toHaveLength(0));
          expect(screen.getByTestId('scheduler-enabled-checkbox')).toBeChecked();
          expect(screen.getByRole('button', { name: /保存配置/ })).toBeDisabled();
          if (outcome === 'reload-failed') {
            expect(screen.getByText('配置已导入但刷新失败')).toBeInTheDocument();
          }
        }
        useSystemConfigMock.mockReturnValue(configState);
        page.rerenderSettingsPage();
        if (!screen.queryByLabelText('渠道名称')) {
          fireEvent.click(await screen.findByRole('button', { name: /primary/i }));
        }
        expect(await screen.findByLabelText('渠道名称')).toHaveValue(outcome === 'import-failed' ? '' : 'primary');
        if (outcome !== 'import-failed') {
          act(() => { void page.router.navigate('/chat'); });
          await waitFor(() => expect(page.router.state.location.pathname).toBe('/chat'));
        }
      },
    );

    it('guards LLM-only edits and clears local editors on the actual Reset button', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'ai_model', hasDirty: false }));
      const { router } = renderSettingsPage();
      fireEvent.click(await screen.findByRole('button', { name: 'edit incomplete llm draft' }));
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));
      act(() => { void router.navigate('/chat'); });
      fireEvent.click(await screen.findByRole('button', { name: '取消' }));
      fireEvent.click(screen.getByRole('button', { name: '重置' }));
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(0));
      expect(resetDraft).toHaveBeenCalledTimes(1);
      act(() => { void router.navigate('/chat'); });
      await waitFor(() => expect(router.state.location.pathname).toBe('/chat'));
    });

    it('keeps the LLM-only guard after Cancel and releases it when the editor becomes clean', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'ai_model', hasDirty: false }));
      const { router } = renderSettingsPage();
      fireEvent.click(await screen.findByRole('button', { name: 'edit incomplete llm draft' }));
      act(() => { void router.navigate('/chat'); });
      fireEvent.click(await screen.findByRole('button', { name: '取消' }));
      expect(beforeUnloadListeners.length).toBe(1);
      expect(resetDraft).not.toHaveBeenCalled();
      fireEvent.click(screen.getByRole('button', { name: 'restore llm draft' }));
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(0));
      act(() => { void router.navigate('/chat'); });
      await waitFor(() => expect(router.state.location.pathname).toBe('/chat'));
    });

    it('discards LLM-only edits and preserves the pending destination', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ activeCategory: 'ai_model', hasDirty: false }));
      const { router } = renderSettingsPage();
      fireEvent.click(await screen.findByRole('button', { name: 'edit incomplete llm draft' }));
      act(() => { void router.navigate('/chat?draft=1#target'); });
      fireEvent.click(await screen.findByRole('button', { name: '放弃并离开' }));
      await waitFor(() => expect(router.state.location.pathname).toBe('/chat'));
      expect(router.state.location.search).toBe('?draft=1');
      expect(router.state.location.hash).toBe('#target');
      expect(resetDraft).toHaveBeenCalledTimes(1);
      expect(beforeUnloadListeners.length).toBe(0);
    });

    it('registers a beforeunload listener when there are unsaved drafts', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 2 }));

      renderSettingsPage();
      // Wait for the initial load effect (which also re-renders with the
      // mocked system-config state) to settle — the guard effect runs as a
      // layout commit after the first paint with effectiveHasDirty === true.
      await waitFor(() => {
        expect(beforeUnloadListeners.length).toBeGreaterThanOrEqual(1);
      });
    });

    it('does not register a beforeunload listener when no drafts are dirty', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: false, dirtyCount: 0 }));

      renderSettingsPage();

      // Give any pending effects (load() promise, async setState) time to settle
      // before we assert no listener was attached.
      await waitFor(() => expect(load).toHaveBeenCalledTimes(1));
      expect(beforeUnloadListeners.length).toBe(0);
    });

    it('guards the navigation by setting returnValue on the synthetic event', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 1 }));

      renderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));

      const event = new Event('beforeunload') as BeforeUnloadEvent;
      // jsdom does not implement `returnValue` on Event, so we attach a plain
      // property to mirror the DOM semantics in tests.
      Object.defineProperty(event, 'returnValue', {
        configurable: true,
        writable: true,
        value: '',
      });
      const handler = beforeUnloadListeners[0]!;
      const result = handler(event);

      expect(event.returnValue).not.toBe('');
      // The handler also returns the message so older browsers (Firefox) can
      // surface it natively.
      expect(result).toBe(event.returnValue);
    });

    it('re-attaches a fresh listener when the dirty state flips back and forth', async () => {
      // Start dirty → listener attached.
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 1 }));
      const { rerenderSettingsPage } = renderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));
      const firstHandler = beforeUnloadListeners[0]!;

      // Clear dirty → listener removed on next render.
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: false, dirtyCount: 0 }));
      rerenderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(0));

      // Dirty again → new listener attached, distinct from the original reference.
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 1 }));
      rerenderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));
      expect(beforeUnloadListeners[0]).not.toBe(firstHandler);
    });

    // ───────────────────────────────────────────────────────────────────────
    // In-app route guards (issue #1948 — ZhuLinsen reviewer contract points
    // 3–6). `beforeunload` only fires on reload / tab close / external nav;
    // these tests exercise the `useBlocker`-backed `ConfirmDialog` flow that
    // covers SPA-internal navigation (sidebar `NavLink`, `navigate()`,
    // browser back/forward).
    // ───────────────────────────────────────────────────────────────────────

    it('prompts on in-app navigation away from /settings when dirty, and stays when cancelled', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 1 }));

      const { router } = renderSettingsPage();
      // Wait for the useBlocker effect to attach (it depends on
      // effectiveHasDirty, which is derived from the mocked hook return value
      // after the initial load effect runs).
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));
      expect(router.state.location.pathname).toBe('/settings');

      // Trigger an in-app navigation to /chat — the blocker should intercept
      // and keep us on /settings, surfacing the confirm dialog instead.
      act(() => {
        void router.navigate('/chat');
      });

      await waitFor(() => {
        expect(screen.getByText('当前页面还有未保存的修改。刷新页面、关闭标签页或离开该页面会丢弃这些本地草稿。要继续吗？')).toBeInTheDocument();
      });
      // Blocker cancelled the navigation: still on /settings, and the stub
      // chat page has NOT mounted.
      expect(router.state.location.pathname).toBe('/settings');
      expect(screen.queryByTestId('chat-page-stub')).not.toBeInTheDocument();
      fireEvent.click(screen.getByRole('button', { name: '取消' }));
      expect(router.state.location.pathname).toBe('/settings');
      expect(resetDraft).not.toHaveBeenCalled();
      expect(screen.queryByRole('button', { name: '放弃并离开' })).not.toBeInTheDocument();
      act(() => { void router.navigate('/chat'); });
      expect(await screen.findByRole('button', { name: '放弃并离开' })).toBeInTheDocument();
    });

    it('discards the draft and proceeds to the target route on confirm', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 1 }));
      resetDraft.mockClear();

      const { router } = renderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));

      act(() => {
        void router.navigate('/chat');
      });

      await waitFor(() => {
        expect(screen.getByRole('button', { name: '放弃并离开' })).toBeInTheDocument();
      });

      // Confirm → resetDraft flips dirty to false, then proceed() replays the
      // pending navigation to /chat.
      fireEvent.click(screen.getByRole('button', { name: '放弃并离开' }));

      await waitFor(() => {
        expect(resetDraft).toHaveBeenCalledTimes(1);
      });
      await waitFor(() => {
        expect(router.state.location.pathname).toBe('/chat');
      });
      expect(screen.getByTestId('chat-page-stub')).toBeInTheDocument();
    });

    it('does not prompt on in-app navigation when there are no dirty drafts', async () => {
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: false, dirtyCount: 0 }));

      const { router } = renderSettingsPage();
      await waitFor(() => expect(load).toHaveBeenCalledTimes(1));
      expect(beforeUnloadListeners.length).toBe(0);

      act(() => {
        void router.navigate('/chat');
      });

      await waitFor(() => {
        expect(router.state.location.pathname).toBe('/chat');
      });
      // No dialog ever shown.
      expect(screen.queryByText('当前页面还有未保存的修改。刷新页面、关闭标签页或离开该页面会丢弃这些本地草稿。要继续吗？')).not.toBeInTheDocument();
    });

    it('prompts when the user triggers browser-style back navigation away from /settings', async () => {
      // Back navigation is approximated with `router.navigate(-1)` from a
      // history that contains a non-/settings entry — this is the closest
      // jsdom-equivalent to a real `popstate` for the data router.
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 1 }));

      const { router } = renderSettingsPage(['/chat', '/settings']);
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));
      expect(router.state.location.pathname).toBe('/settings');

      act(() => {
        void router.navigate(-1);
      });

      await waitFor(() => {
        expect(screen.getByText('当前页面还有未保存的修改。刷新页面、关闭标签页或离开该页面会丢弃这些本地草稿。要继续吗？')).toBeInTheDocument();
      });
      // Cancelled: still on /settings, history entry not popped.
      expect(router.state.location.pathname).toBe('/settings');
    });

    it('clears the in-app guard once dirty drops to zero (after reset button)', async () => {
      // Start dirty → both beforeunload listener and useBlocker active.
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 2 }));
      const { router, rerenderSettingsPage } = renderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));

      // Simulate "Reset" button success — dirty clears, listener should be
      // torn down and a subsequent in-app navigation should NOT prompt.
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: false, dirtyCount: 0 }));
      rerenderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(0));

      act(() => {
        void router.navigate('/chat');
      });
      await waitFor(() => {
        expect(router.state.location.pathname).toBe('/chat');
      });
      expect(screen.queryByText('当前页面还有未保存的修改。刷新页面、关闭标签页或离开该页面会丢弃这些本地草稿。要继续吗？')).not.toBeInTheDocument();
    });

    it('clears the in-app guard once dirty drops to zero (after save success)', async () => {
      // Same shape as the reset-button variant, but the contract point 5 also
      // explicitly calls out "保存成功后必须立即解除两类 guard". Save success
      // is the same observable from the hook's perspective: hasDirty flips
      // false. We model that here by switching the mock return value.
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: true, dirtyCount: 1 }));
      const { router, rerenderSettingsPage } = renderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(1));

      // Save success — dirty clears.
      useSystemConfigMock.mockReturnValue(buildSystemConfigState({ hasDirty: false, dirtyCount: 0 }));
      rerenderSettingsPage();
      await waitFor(() => expect(beforeUnloadListeners.length).toBe(0));

      act(() => {
        void router.navigate('/chat');
      });
      await waitFor(() => {
        expect(router.state.location.pathname).toBe('/chat');
      });
      expect(screen.queryByText('当前页面还有未保存的修改。刷新页面、关闭标签页或离开该页面会丢弃这些本地草稿。要继续吗？')).not.toBeInTheDocument();
    });
  });
});
